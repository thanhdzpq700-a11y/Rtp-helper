# RTP Helper (Meteor addon, MC 1.21.11)

Mod chi lo phan RTP, lam theo Sand Helper. Dung chung Meteor Client: category "RTP Helper" trong Meteor GUI, lenh `.rtphelper` (alias `.rh`).

## Build
Can JDK 21 va Gradle 9.2 (hoac copy thu muc src/ vao Meteor addon template cho 1.21.11).

    gradle wrapper --gradle-version 9.2.0
    ./gradlew build

File jar nam trong build/libs/rtp-helper-1.0.0.jar, bo vao thu muc mods cung Meteor Client.
Neu Gradle bao sai version yarn/meteor thi sua trong gradle.properties cho khop (yarn_mappings, meteor_version).

## Luu y
- Tat `tu-dong-rtp` cua Sand Helper de 2 mod khong /rtp chong nhau.
- Logic: Baritone dang dao thi KHONG rtp. Chi RTP khi Baritone dung han (cho-baritone-dung tick) hoac chat Baritone bao het cat.
- Sau RTP: quet vung 2x2 chunk, duoi 30 block cat dao duoc hoac o bien thi RTP tiep, du thi bat Baritone dao.
- Lenh: .rtphelper rtp | stop | status | scan

## Build bang GitHub Actions (khong can cai gi tren may)
1. Tao repo GitHub moi, upload toan bo noi dung thu muc nay (nho giu thu muc .github).
2. Vao tab Actions, doi workflow "build" chay xong.
3. Mo lan chay do, tai artifact "rtp-helper-jar" ve, giai nen ra file .jar.
