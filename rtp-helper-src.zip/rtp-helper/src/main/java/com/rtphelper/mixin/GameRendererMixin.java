package com.rtphelper.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.rtphelper.modules.RtpHelper;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @ModifyExpressionValue(
        method = "render",
        at = @At(value = "FIELD", target = "Lnet/minecraft/client/option/GameOptions;pauseOnLostFocus:Z")
    )
    private boolean rtphelper$pauseOnLostFocus(boolean original) {
        return original && !RtpHelper.shouldRunUnfocused();
    }
}
