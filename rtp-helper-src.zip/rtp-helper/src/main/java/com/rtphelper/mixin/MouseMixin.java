package com.rtphelper.mixin;

import com.rtphelper.modules.RtpHelper;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {
    @Inject(method = "lockCursor", at = @At("HEAD"), cancellable = true)
    private void rtphelper$onLockCursor(CallbackInfo ci) {
        if (RtpHelper.shouldBlockCursorLock()) ci.cancel();
    }
}
