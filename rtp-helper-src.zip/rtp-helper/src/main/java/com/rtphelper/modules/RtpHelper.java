package com.rtphelper.modules;

import com.rtphelper.RtpHelperAddon;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.ModuleListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.world.Nuker;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.s2c.play.OverlayMessageS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.lang.reflect.Field;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * RTP Helper: chi lo phan RTP.
 *
 * Vong lap:
 *  - Bat module / sau moi lan /rtp: cho chunk load, quet vung chunk (mac dinh 2x2) dem cat dao duoc.
 *  - Duoi nguong (mac dinh 30) hoac dang o bien: /rtp tiep.
 *  - Du cat: bat lai Nuker (neu bi tam dung) va cho Baritone mine block-can-dao.
 *  - Baritone dang dao thi KHONG /rtp du quet khong thay cat. Chi khi Baritone dung han thi /rtp.
 */
public class RtpHelper extends Module {

    private enum State {
        DUMP_JUNK,         // dang vut item rac truoc khi /rtp
        RTP_SCRIPT,        // dang chay script-rtp (/rtp, click menu)
        RTP_WAIT_TP,       // cho duoc dich chuyen
        RTP_COOLDOWN,      // server cooldown / loi, cho roi thu lai
        WAIT_CHUNKS,       // da dich chuyen, cho chunk load roi quet cat
        MINING,            // Baritone dang dao
        SELL,              // dang ban cat vao /order
        BUY_XP,            // dang mua binh XP
        REPAIR             // dang sua xeng bang Mending
    }

    private enum Kind { WAIT, CMD, WAITGUI, CLICK, CLOSE }

    private enum RPhase { SELECT, TO_OFFHAND, PICK_XP, AIM, THROW, WAIT_ORBS, RESTORE, DONE }

    private static final class Step {
        Kind kind;
        int num;            // WAIT: so tick
        String arg;         // CMD: lenh
        boolean bySlot;     // CLICK: slot:N hay id:xxx
        int slot;
        String id;
        boolean optional;   // buoc co dau ?
        String raw;
    }

    private record ScanResult(int sand, int hidden, boolean allLoaded, int chunks) {}

    // ---------------------------------------------------------------- settings

    private final SettingGroup sgGeneral = settings.createGroup("Chung");
    private final SettingGroup sgRtp = settings.createGroup("RTP");
    private final SettingGroup sgAdvanced = settings.createGroup("Nang cao");
    private final SettingGroup sgScript = settings.createGroup("Script");
    private final SettingGroup sgJunk = settings.createGroup("Don rac");
    private final SettingGroup sgJobs = settings.createGroup("Ban va Sua xeng");
    private final SettingGroup sgHuman = settings.createGroup("Gia nguoi");

    // Chung
    private final Setting<Boolean> baritoneMineAgain = sgGeneral.add(new BoolSetting.Builder()
        .name("baritone-dao-lai")
        .description("Sau RTP thay du cat thi bat lai Baritone mine block-can-dao. Tat di thi khong theo doi duoc Baritone dung.")
        .defaultValue(true)
        .build());

    private final Setting<List<Module>> pauseModules = sgGeneral.add(new ModuleListSetting.Builder()
        .name("tam-dung-module")
        .description("Module tam tat khi dang /rtp, xong thi bat lai (mac dinh: Nuker).")
        .defaultValue(Nuker.class)
        .build());

    private final Setting<Boolean> stopBaritone = sgGeneral.add(new BoolSetting.Builder()
        .name("tam-dung-baritone")
        .description("Tam dung (pause) Baritone khi dang /rtp, xong thi resume.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> autoShovel = sgGeneral.add(new BoolSetting.Builder()
        .name("tu-cam-xeng")
        .description("Khi dang dao ma tay khong cam xeng (xeng bi ket trong hotbar) thi tu chon lai xeng tot nhat trong hotbar.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> runUnfocused = sgGeneral.add(new BoolSetting.Builder()
        .name("chay-khi-alt-tab")
        .description("Alt-tab ra ngoai van chay: game khong tu mo menu pause khi mat focus.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> noCursorLock = sgGeneral.add(new BoolSetting.Builder()
        .name("khong-chiem-chuot")
        .description("Khong khoa/chiem chuot khi module dang bat. Tat di neu muon tu xoay camera.")
        .defaultValue(true)
        .build());

    // RTP
    private final Setting<List<Block>> targetBlocks = sgRtp.add(new BlockListSetting.Builder()
        .name("block-can-dao")
        .description("Block can tim sau RTP va cho Baritone dao.")
        .defaultValue(Blocks.SAND)
        .build());

    private final Setting<Integer> minBlocks = sgRtp.add(new IntSetting.Builder()
        .name("rtp-khi-con-duoi")
        .description("Vung quet co it hon bay nhieu block dao duoc thi RTP.")
        .defaultValue(30)
        .range(1, 100000)
        .sliderRange(1, 500)
        .build());

    private final Setting<Integer> areaSize = sgRtp.add(new IntSetting.Builder()
        .name("vung-quet-chunk")
        .description("Quet N x N chunk quanh ban (2 = 2x2 chunk, chon 4 chunk sat ban nhat).")
        .defaultValue(2)
        .range(1, 3)
        .sliderRange(1, 3)
        .build());

    private final Setting<Integer> maxDy = sgRtp.add(new IntSetting.Builder()
        .name("lech-do-cao-toi-da")
        .description("Chi tinh cat lech do cao (Y) so voi ban khong qua bay nhieu block.")
        .defaultValue(48)
        .range(1, 400)
        .sliderRange(8, 128)
        .build());

    private final Setting<Boolean> exposedOnly = sgRtp.add(new BoolSetting.Builder()
        .name("chi-tinh-cat-lo-ra")
        .description("Chi tinh khoi cat co it nhat mot mat tiep xuc khong khi (nhin thay, toi duoc). Khong tinh cat chon sau trong dat/da.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> skipUnderwater = sgRtp.add(new BoolSetting.Builder()
        .name("bo-cat-duoi-nuoc")
        .description("Khong tinh block co nuoc/dung dich o ngay phia tren (cat o day bien, day song).")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> checkEmptyWhileMining = sgRtp.add(new BoolSetting.Builder()
        .name("kiem-tra-het-cat-khi-dao")
        .description("Khi Baritone dang dao, dinh ky quet cat quanh ban. Het cat thi dung Baritone va /rtp (tranh Baritone dao xuong long dat).")
        .defaultValue(true)
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<Integer> emptyRadius = sgRtp.add(new IntSetting.Builder()
        .name("ban-kinh-chunk-het-cat")
        .description("Ban kinh (chunk) quet de biet con cat cho Baritone dao hay khong. Nen <= render distance.")
        .defaultValue(6)
        .range(1, 16)
        .sliderRange(1, 12)
        .visible(() -> baritoneMineAgain.get() && checkEmptyWhileMining.get())
        .build());

    private final Setting<Integer> emptyBelow = sgRtp.add(new IntSetting.Builder()
        .name("het-cat-khi-con-duoi")
        .description("Trong ban kinh tren con it hon bay nhieu block cat thi coi la het cat.")
        .defaultValue(3)
        .range(1, 1000)
        .sliderRange(1, 50)
        .visible(() -> baritoneMineAgain.get() && checkEmptyWhileMining.get())
        .build());

    private final Setting<Boolean> rtpWhenStuck = sgRtp.add(new BoolSetting.Builder()
        .name("rtp-khi-dung-yen")
        .description("Dung yen mot cho qua lau khi dang dao (Baritone ket, khong dat/dao duoc block, block ma) thi /rtp.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> stuckSeconds = sgRtp.add(new IntSetting.Builder()
        .name("thoi-gian-dung-yen")
        .description("Dung yen bao nhieu giay thi /rtp.")
        .defaultValue(60)
        .range(10, 900)
        .sliderRange(20, 300)
        .visible(rtpWhenStuck::get)
        .build());

    private final Setting<Integer> stuckDistance = sgRtp.add(new IntSetting.Builder()
        .name("khoang-cach-dung-yen")
        .description("Di chuyen it hon bay nhieu block trong khoang thoi gian tren thi tinh la dung yen.")
        .defaultValue(2)
        .range(1, 30)
        .sliderRange(1, 10)
        .visible(rtpWhenStuck::get)
        .build());

    private final Setting<Boolean> rtpLowHealth = sgRtp.add(new BoolSetting.Builder()
        .name("rtp-khi-mau-thap")
        .description("Mau xuong duoi muc phan tram ben duoi (bi quai/nguoi tan cong, ngat nuoc...) khi dang dao thi /rtp de thoat.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> lowHealthPercent = sgRtp.add(new IntSetting.Builder()
        .name("phan-tram-mau")
        .description("Muc mau toi thieu (% thanh mau). Duoi muc nay thi /rtp.")
        .defaultValue(60)
        .range(1, 99)
        .sliderRange(10, 90)
        .visible(rtpLowHealth::get)
        .build());

    private final Setting<Boolean> rtpOnPlayer = sgRtp.add(new BoolSetting.Builder()
        .name("rtp-khi-thay-nguoi-choi")
        .description("Tu quet nguoi choi o gan, bao ten + khoang cach trong chat va /rtp de tranh bi giet.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> playerRange = sgRtp.add(new IntSetting.Builder()
        .name("khoang-cach-nguoi-choi")
        .description("Chi tinh nguoi choi trong khoang cach nay (block). 0 = moi nguoi dang duoc tai trong the gioi.")
        .defaultValue(64)
        .range(0, 500)
        .sliderRange(16, 200)
        .visible(rtpOnPlayer::get)
        .build());

    private final Setting<Boolean> ignoreFriends = sgRtp.add(new BoolSetting.Builder()
        .name("bo-qua-ban-be")
        .description("Khong tinh ban be trong danh sach Friends cua Meteor.")
        .defaultValue(true)
        .visible(rtpOnPlayer::get)
        .build());

    private final Setting<List<String>> playerWhitelist = sgRtp.add(new StringListSetting.Builder()
        .name("ten-bo-qua")
        .description("Ten nguoi choi khong tinh la nguy hiem (khong phan biet hoa thuong).")
        .defaultValue(new ArrayList<>())
        .visible(rtpOnPlayer::get)
        .build());

    private final Setting<Integer> playerCooldown = sgRtp.add(new IntSetting.Builder()
        .name("nguoi-choi-cho-lai")
        .description("Sau moi lan /rtp vi nguoi choi, bo qua canh bao trong bay nhieu giay (tranh /rtp lien tuc).")
        .defaultValue(10)
        .range(3, 600)
        .sliderRange(5, 120)
        .visible(rtpOnPlayer::get)
        .build());

    private final Setting<Integer> maxDrop = sgRtp.add(new IntSetting.Builder()
        .name("do-sau-toi-da")
        .description("Ban tut xuong sau hon bay nhieu block so voi luc bat dau dao thi dung Baritone va /rtp (0 = tat).")
        .defaultValue(15)
        .range(0, 200)
        .sliderRange(0, 60)
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<Boolean> rtpInOcean = sgRtp.add(new BoolSetting.Builder()
        .name("rtp-khi-o-bien")
        .description("Dap xuong bien (biome ocean) hoac dang boi trong nuoc thi /rtp tiep.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> maxRtp = sgRtp.add(new IntSetting.Builder()
        .name("so-lan-rtp-toi-da")
        .description("RTP lien tiep toi da bay nhieu lan ma van khong co cat (0 = toi khi co cat).")
        .defaultValue(0)
        .range(0, 1000)
        .sliderRange(0, 100)
        .build());

    private final Setting<Integer> baritoneIdleTicks = sgRtp.add(new IntSetting.Builder()
        .name("cho-baritone-dung")
        .description("Baritone khong di chuyen/dao lien tuc bay nhieu tick thi coi nhu da het cat va /rtp (20 tick = 1 giay).")
        .defaultValue(80)
        .range(20, 1200)
        .sliderRange(20, 400)
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<List<String>> baritoneKeywords = sgRtp.add(new StringListSetting.Builder()
        .name("tu-khoa-baritone-het-cat")
        .description("Tin nhan chat cua Baritone chua cac tu nay (khong phan biet hoa thuong/dau) thi /rtp ngay.")
        .defaultValue(new ArrayList<>(List.of("canceling", "no known locations", "khong tim thay")))
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<List<String>> instantKeywords = sgRtp.add(new StringListSetting.Builder()
        .name("tu-khoa-rtp-ngay")
        .description("Tin nhan (chat HOAC action bar chu do tren hotbar) chua cac tu nay thi /rtp ngay khi dang dao. Mac dinh: 'You are at a world border'.")
        .defaultValue(new ArrayList<>(List.of("world border")))
        .build());

    private final Setting<List<String>> cooldownKeywords = sgRtp.add(new StringListSetting.Builder()
        .name("tu-khoa-cooldown")
        .description("Tin nhan server chua cac tu nay thi coi la dang cooldown RTP, doc so giay trong tin de cho dung.")
        .defaultValue(new ArrayList<>(List.of("cooldown", "please wait", "vui long cho")))
        .build());

    // Nang cao
    private final Setting<Integer> stepDelay = sgAdvanced.add(new IntSetting.Builder()
        .name("do-tre-moi-buoc")
        .description("Tick nghi giua moi buoc/click (20 tick = 1 giay). Tang len neu lag.")
        .defaultValue(8)
        .range(1, 100)
        .sliderRange(1, 40)
        .build());

    private final Setting<Integer> randomDelay = sgAdvanced.add(new IntSetting.Builder()
        .name("do-tre-ngau-nhien")
        .description("Cong them 0..N tick ngau nhien vao moi do tre cho giong nguoi that.")
        .defaultValue(4)
        .range(0, 40)
        .sliderRange(0, 20)
        .build());

    private final Setting<Integer> menuTimeout = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-menu-toi-da")
        .description("Tick toi da cho menu/item hien ra truoc khi bao loi.")
        .defaultValue(100)
        .range(10, 600)
        .sliderRange(20, 300)
        .build());

    private final Setting<Integer> tpTimeout = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-dich-chuyen")
        .description("Sau /rtp cho toi da bay nhieu tick de duoc dich chuyen.")
        .defaultValue(200)
        .range(20, 1200)
        .sliderRange(40, 600)
        .build());

    private final Setting<Integer> chunkDelay = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-load-chunk")
        .description("Sau khi dich chuyen cho it nhat bay nhieu tick roi moi quet cat.")
        .defaultValue(40)
        .range(0, 400)
        .sliderRange(0, 200)
        .build());

    private final Setting<Integer> chunkTimeout = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-chunk-toi-da")
        .description("Cho chunk trong vung quet load toi da bay nhieu tick, qua han van chua du thi RTP lai.")
        .defaultValue(200)
        .range(20, 1200)
        .sliderRange(40, 600)
        .build());

    private final Setting<Integer> retryWait = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-rtp-lai")
        .description("/rtp khong dich chuyen (server cooldown) hoac loi thi cho bay nhieu tick roi thu lai.")
        .defaultValue(200)
        .range(20, 2400)
        .sliderRange(40, 1200)
        .build());

    private final Setting<Integer> maxErrors = sgAdvanced.add(new IntSetting.Builder()
        .name("so-loi-toi-da")
        .description("Loi lien tiep bay nhieu lan thi tat module.")
        .defaultValue(5)
        .range(1, 50)
        .sliderRange(1, 20)
        .build());

    private final Setting<Boolean> debug = sgAdvanced.add(new BoolSetting.Builder()
        .name("debug")
        .description("In tung buoc ra chat.")
        .defaultValue(false)
        .build());

    // Script
    private final Setting<List<String>> scriptRtp = sgScript.add(new StringListSetting.Builder()
        .name("script-rtp")
        .description("Cac buoc RTP (/rtp > click slot 0). Lenh: cmd /x | wait N | waitgui | click slot:N | click id:item | close. Them ? dau dong neu buoc tuy chon.")
        .defaultValue(new ArrayList<>(List.of("cmd /rtp", "click slot:0 & any")))
        .build());

    // Don rac
    private final Setting<Boolean> dumpJunk = sgJunk.add(new BoolSetting.Builder()
        .name("vut-rac-truoc-rtp")
        .description("Truoc khi /rtp, neu trong tui co nhieu item rac (danh sach item-rac) thi vut het roi moi /rtp.")
        .defaultValue(true)
        .build());

    private final Setting<List<Item>> junkItems = sgJunk.add(new ItemListSetting.Builder()
        .name("item-rac")
        .description("Item can vut. Ban tu chon. De trong = khong vut gi.")
        .defaultValue(new ArrayList<>())
        .visible(dumpJunk::get)
        .build());

    private final Setting<Integer> dumpAtRtp = sgJunk.add(new IntSetting.Builder()
        .name("vut-rac-o-lan-rtp-thu")
        .description("Chi vut rac dung o lan RTP thu N trong moi dot (dot = tu luc bat dau dao toi khi tim thay cat moi). 2 = bo qua lan RTP dau, chi vut o lan thu hai.")
        .defaultValue(2)
        .range(1, 20)
        .sliderRange(1, 6)
        .visible(dumpJunk::get)
        .build());

    private final Setting<Integer> junkMinSlots = sgJunk.add(new IntSetting.Builder()
        .name("so-o-rac-toi-thieu")
        .description("Chi vut khi co it nhat bay nhieu o chua item rac.")
        .defaultValue(3)
        .range(1, 36)
        .sliderRange(1, 20)
        .visible(dumpJunk::get)
        .build());

    private final Setting<Boolean> junkOpenInv = sgJunk.add(new BoolSetting.Builder()
        .name("mo-tui-do-khi-vut")
        .description("Mo tui do (nhu bam E) luc vut cho giong nguoi that. Tat di thi vut am tham.")
        .defaultValue(true)
        .visible(dumpJunk::get)
        .build());

    private final Setting<Boolean> junkLookLevel = sgJunk.add(new BoolSetting.Builder()
        .name("nhin-ngang-khi-vut")
        .description("Ngang dau len nhin thang truoc khi vut (xoay muot, khong giat) de item bi nem ra xa, khong roi sat chan roi bi nhat lai.")
        .defaultValue(true)
        .visible(dumpJunk::get)
        .build());

    private final Setting<Integer> junkDelay = sgJunk.add(new IntSetting.Builder()
        .name("do-tre-vut-rac")
        .description("Tick nghi giua moi lan vut (cong them do-tre-ngau-nhien). 20 tick = 1 giay.")
        .defaultValue(6)
        .range(1, 60)
        .sliderRange(2, 30)
        .visible(dumpJunk::get)
        .build());

    private final Setting<Boolean> junkSkipEnchanted = sgJunk.add(new BoolSetting.Builder()
        .name("khong-vut-do-phep")
        .description("Khong vut item co phu phep (hieu ung long lanh) du nam trong danh sach.")
        .defaultValue(true)
        .visible(dumpJunk::get)
        .build());

    // Ban cat / mua XP / sua xeng
    private final Setting<Boolean> autoSell = sgJobs.add(new BoolSetting.Builder()
        .name("tu-dong-ban")
        .description("Tui day thi ban vao /order.")
        .defaultValue(true)
        .build());

    private final Setting<List<Item>> sellItems = sgJobs.add(new ItemListSetting.Builder()
        .name("item-ban")
        .description("Item duoc ban.")
        .defaultValue(new ArrayList<>(List.of(Items.SAND)))
        .visible(autoSell::get)
        .build());

    private final Setting<Integer> sellFreeSlots = sgJobs.add(new IntSetting.Builder()
        .name("ban-khi-con-o-trong")
        .description("Ban khi tui con <= bay nhieu o trong (0 = day han).")
        .defaultValue(0)
        .range(0, 35)
        .sliderRange(0, 10)
        .visible(autoSell::get)
        .build());

    private final Setting<Integer> minSell = sgJobs.add(new IntSetting.Builder()
        .name("ban-toi-thieu")
        .description("Co it nhat bay nhieu item moi ban.")
        .defaultValue(32)
        .range(1, 2304)
        .sliderRange(1, 512)
        .visible(autoSell::get)
        .build());

    private final Setting<Integer> maxSellRounds = sgJobs.add(new IntSetting.Builder()
        .name("so-lan-ban-toi-da")
        .description("Ban xong van day tui thi ban lai toi da bay nhieu lan.")
        .defaultValue(3)
        .range(1, 20)
        .sliderRange(1, 10)
        .visible(autoSell::get)
        .build());

    private final Setting<List<String>> sellScript = sgJobs.add(new StringListSetting.Builder()
        .name("script-ban")
        .description("Cac buoc ban vao order (HugoSMP). Lenh: cmd /x | wait N | waitgui | click slot:N | click id:item | close. Them ? dau dong neu buoc tuy chon.")
        .defaultValue(new ArrayList<>(List.of("wait 10", "cmd /order sand", "waitgui", "click id:sand", "click slot:6 & any", "click slot:8 & any")))
        .visible(autoSell::get)
        .build());

    private final Setting<Boolean> autoRepair = sgJobs.add(new BoolSetting.Builder()
        .name("tu-dong-sua-xeng")
        .description("Xeng sap hu thi mua XP va nem de sua (can xeng co Mending).")
        .defaultValue(true)
        .build());

    private final Setting<Integer> repairBelow = sgJobs.add(new IntSetting.Builder()
        .name("sua-khi-con-phan-tram")
        .description("Xeng con <= bay nhieu % do ben thi sua.")
        .defaultValue(15)
        .range(1, 99)
        .sliderRange(5, 50)
        .visible(autoRepair::get)
        .build());

    private final Setting<Integer> repairTo = sgJobs.add(new IntSetting.Builder()
        .name("sua-den-phan-tram")
        .description("Sua toi bay nhieu % thi ngung nem XP.")
        .defaultValue(90)
        .range(2, 100)
        .sliderRange(30, 100)
        .visible(autoRepair::get)
        .build());

    private final Setting<Integer> maxBuys = sgJobs.add(new IntSetting.Builder()
        .name("so-lan-mua-xp-toi-da")
        .description("Nem het XP ma chua du thi mua them toi da bay nhieu lan.")
        .defaultValue(3)
        .range(1, 20)
        .sliderRange(1, 10)
        .visible(autoRepair::get)
        .build());

    private final Setting<Integer> buyRuns = sgJobs.add(new IntSetting.Builder()
        .name("stack-xp-moi-lan-mua")
        .description("Moi lan mua, chay script-mua-xp bay nhieu lan (moi lan mua mot stack). Bi gioi han boi so o trong cua tui.")
        .defaultValue(3)
        .range(1, 10)
        .sliderRange(1, 6)
        .visible(autoRepair::get)
        .build());

    private final Setting<List<String>> buyScript = sgJobs.add(new StringListSetting.Builder()
        .name("script-mua-xp")
        .description("Cac buoc mua binh XP (HugoSMP). Cung cu phap voi script-ban.")
        .defaultValue(new ArrayList<>(List.of("cmd /shop", "click id:totem_of_undying", "click id:experience_bottle", "click slot:17 & any", "click slot:23 & any", "?click slot:23 & any")))
        .visible(autoRepair::get)
        .build());

    private final Setting<Integer> throwDelay = sgJobs.add(new IntSetting.Builder()
        .name("do-tre-nem-xp")
        .description("Tick giua moi lan nem binh XP (cong them do-tre-ngau-nhien).")
        .defaultValue(8)
        .range(2, 60)
        .sliderRange(4, 30)
        .visible(autoRepair::get)
        .build());

    private final Setting<Integer> orbWait = sgJobs.add(new IntSetting.Builder()
        .name("cho-xp-bay-vao")
        .description("Nem xong cho bay nhieu tick de XP bay vao nguoi va sua xeng.")
        .defaultValue(60)
        .range(10, 400)
        .sliderRange(20, 200)
        .visible(autoRepair::get)
        .build());

    // Gia nguoi
    private final Setting<Boolean> humanMode = sgHuman.add(new BoolSetting.Builder()
        .name("gia-nguoi")
        .description("Bat toan bo che do giong nguoi that: do tre co phan bo tu nhien, do du, phan xa khi mo menu, cho truoc khi /rtp.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> hesitateChance = sgHuman.add(new IntSetting.Builder()
        .name("xac-suat-do-du")
        .description("% co mot lan do du (cham them 1-2 giay) o moi buoc.")
        .defaultValue(6)
        .range(0, 50)
        .sliderRange(0, 20)
        .visible(humanMode::get)
        .build());

    private final Setting<Boolean> fatigue = sgHuman.add(new BoolSetting.Builder()
        .name("met-moi-dan")
        .description("Do tre tang cham theo thoi gian chay lien tuc (toi da +25%), reset khi bat lai module.")
        .defaultValue(true)
        .visible(humanMode::get)
        .build());

    private final Setting<Integer> preRtpMax = sgHuman.add(new IntSetting.Builder()
        .name("cho-truoc-rtp-toi-da")
        .description("Truoc moi lan /rtp (khong khan cap) cho ngau nhien tu 1 toi bay nhieu giay. 0 = tat.")
        .defaultValue(6)
        .range(0, 30)
        .sliderRange(0, 15)
        .visible(humanMode::get)
        .build());

    // ---------------------------------------------------------------- state

    private State state = State.WAIT_CHUNKS;
    private int stateTicks;
    private int wait;
    private int idleTicks;
    private int emptyChecks;
    private int busyGrace;
    private volatile int blacklistGrace;
    private int stuckTicks;
    private volatile String pendingDanger;
    private int dangerCooldown;
    private int playerCheckTicks;
    private final List<Integer> dumpQueue = new ArrayList<>();
    private int dumped;
    private int rtpCount;
    private float dumpPitch;
    private int jobCooldown;
    private int jobFailures;
    private boolean jobsDisabled;
    private int sellRounds;
    private int sellCountBefore;
    private boolean repairAfterSell;
    private int buyRounds;
    private int buyDone;
    private int buyTarget;
    private int repairHome;
    private int repairStartDamage;
    private boolean repairOk;
    private boolean shovelInOffhand;
    private RPhase rphase = RPhase.SELECT;
    private long activatedAt;
    private int preRtpDelay;
    private Object lastScreenSeen;
    private int healthCooldown;
    private boolean warnedNoShovel;
    private double stuckX, stuckY, stuckZ;
    private volatile String pendingRtp;
    private static final String BARITONE_EMPTY = "Baritone bao het cat";
    private int remineWait;
    private int remineTries;
    private int mineStartY;
    private int rtpTries;
    private int errors;

    private List<Step> script = new ArrayList<>();
    private int stepIdx;
    private int stepTicks;

    private double startX, startY, startZ;
    private RegistryKey<World> startWorld;

    private final List<Module> pausedModules = new ArrayList<>();
    private boolean baritonePaused;

    public RtpHelper() {
        super(RtpHelperAddon.CATEGORY, "rtp-helper",
            "Tu dong /rtp toi khi co cat (quet vung chunk). Baritone dung dao thi /rtp roi dao tiep.");
    }

    // ---------------------------------------------------------------- static hooks cho mixin

    public static boolean shouldRunUnfocused() {
        RtpHelper m = Modules.get().get(RtpHelper.class);
        return m != null && m.isActive() && m.runUnfocused.get();
    }

    public static boolean shouldBlockCursorLock() {
        RtpHelper m = Modules.get().get(RtpHelper.class);
        return m != null && m.isActive() && m.noCursorLock.get();
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onActivate() {
        wait = 0;
        errors = 0;
        rtpTries = 0;
        idleTicks = 0;
        pausedModules.clear();
        baritonePaused = false;
        dumpQueue.clear();
        rtpCount = 0;
        pendingDanger = null;
        dangerCooldown = 0;
        if (dumpJunk.get() && junkItems.get().isEmpty()) {
            warning("vut-rac-truoc-rtp dang bat nhung item-rac dang trong, se khong vut gi.");
        }
        healthCooldown = 0;
        jobCooldown = 0;
        jobFailures = 0;
        jobsDisabled = false;
        sellRounds = 0;
        buyRounds = 0;
        shovelInOffhand = false;
        activatedAt = System.currentTimeMillis();
        preRtpDelay = 0;
        lastScreenSeen = null;
        pendingRtp = null;
        remineWait = 0;
        remineTries = 0;
        script.clear();
        // Danh gia ngay cho dang dung: du cat thi dao luon, khong thi /rtp.
        state = State.WAIT_CHUNKS;
        stateTicks = chunkDelay.get();
    }

    @Override
    public void onDeactivate() {
        script.clear();
        if (state == State.DUMP_JUNK) closeScreen();
        if (isJobState()) {
            closeScreen();
            restoreShovelIfNeeded();
        }
        resumeOthers();
    }

    @Override
    public String getInfoString() {
        return state.name();
    }

    // ---------------------------------------------------------------- public (command)

    public void requestRtp() {
        if (mc.player == null || mc.world == null) return;
        if (state != State.MINING && state != State.WAIT_CHUNKS) {
            warning("Dang ban lam viec khac (%s), thu lai sau.", state);
            return;
        }
        startRtp("lenh .rtphelper rtp");
    }

    public void stopAll() {
        if (!isActive()) {
            info("Khong co viec gi dang chay.");
            return;
        }
        info("Da dung.");
        toggle();
    }

    public void printStatus() {
        info("Module: %s, trang thai: %s", isActive() ? "BAT" : "TAT (bat len thi moi tu chay)", state);
        info("RTP lien tiep chua co cat: %d, loi lien tiep: %d", rtpTries, errors);
        printScan();
    }

    public void printScan() {
        if (mc.player == null || mc.world == null) return;
        ScanResult r = scan();
        info("Vung %dx%d chunk: %d block dao duoc (%d bi nuoc che), chunk load du: %s. Can >= %d.",
            areaSize.get(), areaSize.get(), r.sand(), r.hidden(), r.allLoaded() ? "co" : "chua", minBlocks.get());
        if (rtpInOcean.get()) info("O bien: %s", isOcean() ? "CO" : "khong");
    }

    // ---------------------------------------------------------------- tick

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        if (noCursorLock.get() && mc.mouse.isCursorLocked()) mc.mouse.unlockCursor();

        // Co nguoi choi: /rtp de tranh bi giet (uu tien cao, khong cho do tre cua module khac).
        if (dangerCooldown > 0) dangerCooldown--;
        if (rtpOnPlayer.get() && dangerCooldown <= 0 && pendingDanger == null && (mc.currentScreen == null || isJobState())
            && (state == State.MINING || state == State.WAIT_CHUNKS || isJobState()) && ++playerCheckTicks >= 10) {
            playerCheckTicks = 0;
            pendingDanger = nearbyPlayers();
        }
        if (pendingDanger != null) {
            String reason = pendingDanger;
            pendingDanger = null;
            if (dangerCooldown <= 0 && (mc.currentScreen == null || isJobState())
                && (state == State.MINING || state == State.WAIT_CHUNKS || isJobState())) {
                if (isJobState()) leaveJobForDanger();
                info("%s, /rtp de tranh bi giet.", reason);
                dangerCooldown = playerCooldown.get() * 20;
                startRtp(reason, reactionTicks()); // phan ung nhu nguoi that, khong tuc thi
                return;
            }
        }

        // Yeu cau RTP tu chat Baritone: xu ly o tick sau, khong stop Baritone ngay trong luc no dang tick.
        if (pendingRtp != null) {
            String reason = pendingRtp;
            pendingRtp = null;
            if (state == State.MINING && !otherBusy()) {
                // Baritone bao "no known locations" khi bi ngap nuoc / dang tinh lai duong, nhung quanh day van con cat:
                // khong /rtp, cho nguoi choi tu len roi bao Baritone dao lai.
                if (BARITONE_EMPTY.equals(reason) && checkEmptyWhileMining.get() && stillHasSand()) {
                    info("Baritone bao het cat nhung quanh day van con cat (co the dang ngap nuoc), khong /rtp. Cho roi dao lai.");
                    blacklistGrace = 400; // 20 giay khong tinh Baritone dung
                    idleTicks = 0;
                    remineWait = 40;
                    remineTries = 0;
                    return;
                }
                info("%s, /rtp.", reason);
                startRtp(reason);
                return;
            }
        }

        // Dang an (Auto Eat) trong luc ban/mua/sua/vut rac: dung chung de khong tranh o hotbar / tay voi Auto Eat.
        if ((isJobState() || state == State.DUMP_JUNK) && otherBusy()) return;

        if (wait > 0) {
            wait--;
            return;
        }

        try {
            switch (state) {
                case DUMP_JUNK -> tickDump();
                case RTP_SCRIPT -> runScript();
                case RTP_WAIT_TP -> tickWaitTeleport();
                case RTP_COOLDOWN -> startRtp("het cho");
                case WAIT_CHUNKS -> tickWaitChunks();
                case MINING -> tickMining();
                case SELL -> tickSell();
                case BUY_XP -> tickBuy();
                case REPAIR -> tickRepair();
            }
        } catch (Throwable t) {
            fail("Loi trong " + state + ": " + t);
        }
    }

    @EventHandler
    private void onMessage(ReceiveMessageEvent event) {
        if (mc.player == null) return;
        String msg = norm(event.getMessage().getString());

        if (state == State.MINING) checkInstant(msg);

        if (state == State.RTP_SCRIPT || state == State.RTP_WAIT_TP) {
            for (String kw : cooldownKeywords.get()) {
                if (!kw.isBlank() && msg.contains(norm(kw))) {
                    int ticks = parseCooldownTicks(msg);
                    dbg("Server cooldown, cho " + ticks + " tick.");
                    closeScreen();
                    state = State.RTP_COOLDOWN;
                    wait = ticks;
                    return;
                }
            }
        } else if (state == State.MINING && baritoneMineAgain.get() && stateTicks > 40) {
            // "Unable to find any path to ..., blacklisting presumably unreachable closest instance":
            // Baritone chi bo qua 1 block cat khong toi duoc va VAN dao tiep -> khong phai het cat.
            // Dong thoi dung dem "Baritone dung" trong luc no dang tinh lai duong (vd bi ngap nuoc).
            if (msg.contains("blacklist")) {
                blacklistGrace = 300; // 15 giay
                return;
            }
            for (String kw : baritoneKeywords.get()) {
                if (!kw.isBlank() && msg.contains(norm(kw))) {
                    // Baritone chi bo qua 1 block cat khong toi duoc ("blacklisting ... closest instance") va VAN dao tiep: khong phai het cat.
                    if (msg.contains("blacklisting")) break;
                    // KHONG stop Baritone o day: tin nhan nay do Baritone in ra giua luc no dang tick,
                    // stop luc do se lam Baritone crash (NullPointerException trong MineProcess).
                    pendingRtp = BARITONE_EMPTY;
                    return;
                }
            }
        }
    }

    /** Action bar (chu do tren hotbar) khong di qua chat, nen doc rieng tu goi OverlayMessage. */
    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (!(event.packet instanceof OverlayMessageS2CPacket p)) return;
        if (state != State.MINING) return;
        checkInstant(norm(p.text().getString()));
    }

    /** Quet nguoi choi trong the gioi client. Tra ve cau bao (ten + khoang cach) hoac null neu khong co. */
    private String nearbyPlayers() {
        double range = playerRange.get();
        Set<String> skip = new HashSet<>();
        for (String n : playerWhitelist.get()) {
            if (n != null && !n.isBlank()) skip.add(n.trim().toLowerCase());
        }

        List<String> found = new ArrayList<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            String name = p.getName().getString();
            if (skip.contains(name.toLowerCase())) continue;
            if (ignoreFriends.get() && Friends.get().isFriend(p)) continue;
            double d = mc.player.distanceTo(p);
            if (range > 0 && d > range) continue;
            found.add(name + " (" + Math.round(d) + " block)");
        }
        if (found.isEmpty()) return null;

        int show = Math.min(4, found.size());
        return "Phat hien nguoi choi gan day: " + String.join(", ", found.subList(0, show))
            + (found.size() > show ? " va " + (found.size() - show) + " nguoi nua" : "");
    }

    private void checkInstant(String normalizedMsg) {
        for (String kw : instantKeywords.get()) {
            if (!kw.isBlank() && normalizedMsg.contains(norm(kw))) {
                // Dat co, tick sau moi xu ly (khong stop Baritone trong luc dang xu ly goi tin/chat).
                pendingRtp = "Gap tin nhan '" + kw.trim() + "'";
                return;
            }
        }
    }

    // ---------------------------------------------------------------- RTP

    private void startRtp(String reason) {
        startRtp(reason, -1);
    }

    /** preDelay < 0: cho ngau nhien 1..N giay truoc khi /rtp (khong khan cap). preDelay >= 0: cho dung so tick do. */
    private void startRtp(String reason, int preDelay) {
        dbg("Bat dau RTP: " + reason);
        pendingRtp = null;
        pauseOthers();

        boolean retry = state == State.RTP_COOLDOWN;

        if (preDelay >= 0) {
            preRtpDelay = preDelay;
        } else if (humanMode.get() && preRtpMax.get() > 0) {
            preRtpDelay = 20 + ThreadLocalRandom.current().nextInt(Math.max(1, preRtpMax.get() * 20 - 20 + 1));
        } else {
            preRtpDelay = 0;
        }

        startX = mc.player.getX();
        startY = mc.player.getY();
        startZ = mc.player.getZ();
        startWorld = mc.world.getRegistryKey();
        idleTicks = 0;

        // Dem lan RTP moi (khong tinh thu lai do cooldown/loi).
        if (!retry) rtpCount++;

        // Nhieu item rac thi vut truoc roi moi /rtp, nhung chi o dung lan RTP thu N cua dot nay.
        if (dumpJunk.get() && rtpCount == dumpAtRtp.get() && !otherBusy() && prepareDump()) return;
        beginScript();
    }

    private void beginScript() {
        script = parseScript(scriptRtp.get());
        stepIdx = 0;
        stepTicks = 0;
        state = State.RTP_SCRIPT;
        stateTicks = 0;
        wait = Math.max(wait, preRtpDelay); // dung yen cho mot chut truoc khi go /rtp
        preRtpDelay = 0;
    }

    // ---------------------------------------------------------------- vut item rac

    private boolean isJunk(ItemStack st) {
        if (st.isEmpty() || !junkItems.get().contains(st.getItem())) return false;
        if (st.isIn(ItemTags.SHOVELS)) return false;                                   // khong bao gio vut xeng
        if (targetBlocks.get().contains(Block.getBlockFromItem(st.getItem()))) return false; // khong vut block dang dao
        if (junkSkipEnchanted.get() && st.hasGlint()) return false;                    // khong vut do phu phep
        return true;
    }

    private boolean prepareDump() {
        dumpQueue.clear();
        if (junkItems.get().isEmpty() || mc.currentScreen != null) return false;

        ScreenHandler h = mc.player.playerScreenHandler;
        ItemStack main = mc.player.getMainHandStack();
        for (int i = 9; i <= 44; i++) { // 9-35 tui chinh, 36-44 hotbar
            ItemStack st = h.getSlot(i).getStack();
            if (st == main) continue;   // khong vut do dang cam tren tay
            if (isJunk(st)) dumpQueue.add(i);
        }

        if (dumpQueue.size() < junkMinSlots.get()) {
            dumpQueue.clear();
            return false;
        }

        info("Co %d o item rac, vut truoc khi /rtp.", dumpQueue.size());
        dumped = 0;
        dumpPitch = ThreadLocalRandom.current().nextFloat() * 6f - 3f; // quanh 0 do, lech nhe cho tu nhien
        state = State.DUMP_JUNK;
        stateTicks = 0;
        if (junkOpenInv.get()) mc.setScreen(new InventoryScreen(mc.player));
        wait = dumpDelay();
        return true;
    }

    private void tickDump() {
        if (dumpQueue.isEmpty()) {
            finishDump();
            return;
        }
        if (junkLookLevel.get() && !aimLevel()) { // dang xoay dau cho nhin ngang, chua vut
            wait = 1;
            return;
        }
        int slot = dumpQueue.remove(0);
        ScreenHandler h = mc.player.playerScreenHandler;
        ItemStack st = h.getSlot(slot).getStack();
        if (isJunk(st) && st != mc.player.getMainHandStack()) {
            mc.interactionManager.clickSlot(h.syncId, slot, 1, SlotActionType.THROW, mc.player); // 1 = vut ca stack
            dumped++;
        }
        wait = dumpDelay();
    }

    /** Xoay pitch ve gan 0 do theo tung buoc nho. Tra ve true khi da nhin ngang. */
    private boolean aimLevel() {
        float cur = mc.player.getPitch();
        float diff = dumpPitch - cur;
        if (Math.abs(diff) < 1f) return true;
        float step = 6f + ThreadLocalRandom.current().nextFloat() * 6f;
        mc.player.setPitch(cur + Math.max(-step, Math.min(step, diff)));
        return false;
    }

    private void finishDump() {
        closeScreen();
        info("Da vut %d o item rac, /rtp.", dumped);
        wait = dumpDelay();
        beginScript();
    }

    private int dumpDelay() {
        int extra = randomDelay.get();
        return human(junkDelay.get() + (extra > 0 ? ThreadLocalRandom.current().nextInt(extra + 1) : 0));
    }

    private boolean hasTeleported() {
        if (startWorld != null && !mc.world.getRegistryKey().equals(startWorld)) return true;
        double dx = mc.player.getX() - startX;
        double dy = mc.player.getY() - startY;
        double dz = mc.player.getZ() - startZ;
        return dx * dx + dy * dy + dz * dz > 64;
    }

    private void tickWaitTeleport() {
        stateTicks++;
        if (hasTeleported()) {
            closeScreen();
            errors = 0;
            state = State.WAIT_CHUNKS;
            stateTicks = 0;
            return;
        }
        if (stateTicks > tpTimeout.get()) {
            info("Chua duoc dich chuyen sau /rtp (server dang cooldown?). Thu lai sau %d tick.", retryWait.get());
            closeScreen();
            state = State.RTP_COOLDOWN;
            wait = retryWait.get();
        }
    }

    private void runScript() {
        if (hasTeleported()) { // server tp luon, khong can click menu
            finishScript();
            return;
        }
        if (stepScript()) finishScript();
    }

    /** Chay buoc ke tiep cua script hien tai. Tra ve true khi script da xong. */
    private boolean stepScript() {
        if (stepIdx >= script.size()) return true;

        Step s = script.get(stepIdx);
        switch (s.kind) {
            case WAIT -> nextStep(s.num);
            case CMD -> {
                sendCommand(s.arg);
                nextStep(nextDelay());
            }
            case WAITGUI -> {
                if (mc.currentScreen instanceof HandledScreen<?>) {
                    lastScreenSeen = mc.currentScreen;
                    nextStep(reactionTicks()); // phan xa sau khi menu hien ra
                } else {
                    stepTimeout(s);
                }
            }
            case CLICK -> {
                if (!(mc.currentScreen instanceof HandledScreen<?> hs)) {
                    stepTimeout(s);
                    return false;
                }
                if (humanMode.get() && lastScreenSeen != mc.currentScreen) { // menu vua hien: cho phan xa roi moi bam
                    lastScreenSeen = mc.currentScreen;
                    wait = reactionTicks();
                    return false;
                }
                ScreenHandler h = hs.getScreenHandler();
                int idx = findSlot(h, s);
                if (idx < 0) {
                    stepTimeout(s);
                    return false;
                }
                mc.interactionManager.clickSlot(h.syncId, idx, 0, SlotActionType.PICKUP, mc.player);
                dbg("click slot " + idx);
                nextStep(nextDelay());
            }
            case CLOSE -> {
                closeScreen();
                nextStep(nextDelay());
            }
        }
        return false;
    }

    private void nextStep(int delay) {
        stepIdx++;
        stepTicks = 0;
        wait = Math.max(wait, delay);
    }

    private void stepTimeout(Step s) {
        if (++stepTicks <= menuTimeout.get()) return;
        if (s.optional) {
            dbg("Bo qua buoc tuy chon: " + s.raw);
            nextStep(0);
        } else {
            fail("Het thoi gian cho buoc: " + s.raw);
        }
    }

    private void finishScript() {
        state = State.RTP_WAIT_TP;
        stateTicks = 0;
    }

    private int findSlot(ScreenHandler h, Step s) {
        if (s.bySlot) {
            if (s.slot < 0 || s.slot >= h.slots.size()) return -1;
            return h.getSlot(s.slot).getStack().isEmpty() ? -1 : s.slot;
        }
        int limit = Math.max(0, h.slots.size() - 36); // bo qua tui do nguoi choi
        for (int i = 0; i < limit; i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (st.isEmpty()) continue;
            if (Registries.ITEM.getId(st.getItem()).getPath().equals(s.id)) return i;
        }
        return -1;
    }

    private void sendCommand(String cmd) {
        if (mc.getNetworkHandler() == null) return;
        if (cmd.startsWith("/")) mc.getNetworkHandler().sendChatCommand(cmd.substring(1));
        else mc.getNetworkHandler().sendChatMessage(cmd);
        dbg("gui: " + cmd);
    }

    private void closeScreen() {
        if (mc.currentScreen != null && mc.player != null) mc.player.closeHandledScreen();
    }

    // ---------------------------------------------------------------- quet cat sau RTP

    private void tickWaitChunks() {
        stateTicks++;
        if (stateTicks < chunkDelay.get()) return;

        ScanResult r = scan();
        if (!r.allLoaded()) {
            if (stateTicks > chunkTimeout.get()) {
                notEnough("chunk chua load du sau " + stateTicks + " tick");
            }
            return;
        }

        if (rtpInOcean.get() && (mc.player.isTouchingWater() || isOcean())) {
            notEnough("dang o bien");
            return;
        }

        if (r.sand() < minBlocks.get()) {
            notEnough("chi co " + r.sand() + " block (can >= " + minBlocks.get() + ", " + r.hidden() + " bi nuoc che)");
            return;
        }

        startMining(r.sand());
    }

    private void notEnough(String reason) {
        rtpTries++;
        if (maxRtp.get() > 0 && rtpTries >= maxRtp.get()) {
            error("RTP %d lan van khong thay cat (%s). Tat module.", rtpTries, reason);
            toggle();
            return;
        }
        info("Cho moi: %s. RTP lai (lan %d).", reason, rtpTries);
        startRtp(reason);
    }

    private void startMining(int count) {
        rtpTries = 0;
        errors = 0;

        if (baritoneMineAgain.get()) {
            Block[] blocks = targetBlocks.get().toArray(new Block[0]);
            if (blocks.length == 0) {
                resumeOthers();
                error("block-can-dao dang trong, Baritone khong biet dao gi.");
                toggle();
                return;
            }
            PathManagers.get().mine(blocks);
        }
        resumeOthers();
        info("Thay %d block cat dao duoc. Baritone dao tiep.", count);

        state = State.MINING;
        stateTicks = 0;
        idleTicks = 0;
        emptyChecks = 0;
        busyGrace = 0;
        blacklistGrace = 0;
        rtpCount = 0; // dot RTP moi se dem lai tu dau
        warnedNoShovel = false;
        resetStuck();
        mineStartY = mc.player.getBlockY();
    }

    private void tickMining() {
        stateTicks++;
        if (stateTicks < 60) { // cho Baritone tinh duong
            resetStuck();
            return;
        }

        // Dang an / dung item: Auto Eat co the pause Baritone, khong phai het cat / ket.
        if (otherBusy()) {
            idleTicks = 0;
            emptyChecks = 0;
            busyGrace = 100; // sau khi no xong, cho Baritone chay lai 5 giay roi moi theo doi tiep
            resetStuck();
            return;
        }
        if (busyGrace > 0) {
            busyGrace--;
            idleTicks = 0;
            resetStuck();
            return;
        }

        // Mau thap thi /rtp de thoat (cooldown 30 giay de khong lap RTP lien tuc khi dang yeu).
        if (rtpLowHealth.get()) {
            if (healthCooldown > 0) {
                healthCooldown--;
            } else if (mc.currentScreen == null) {
                float pct = mc.player.getHealth() / mc.player.getMaxHealth() * 100f;
                if (pct < lowHealthPercent.get()) {
                    info("Mau con %d%% (duoi %d%%), /rtp.", Math.round(pct), lowHealthPercent.get());
                    healthCooldown = 600;
                    startRtp("mau thap", 4);
                    return;
                }
            }
        }

        // Ban cat / mua XP / sua xeng.
        if (jobCooldown > 0) {
            jobCooldown--;
        } else if (!jobsDisabled && stateTicks % 20 == 0 && mc.currentScreen == null
            && (autoSell.get() || autoRepair.get())) {
            checkJobs();
            if (isJobState()) return;
        }

        // Tay khong cam xeng thi cam lai.
        if (autoShovel.get() && stateTicks % 10 == 0) ensureShovel();

        // Dung yen qua lau (Baritone ket, khong dat/dao duoc block, block ma...) thi /rtp.
        if (rtpWhenStuck.get()) {
            double dx = mc.player.getX() - stuckX;
            double dy = mc.player.getY() - stuckY;
            double dz = mc.player.getZ() - stuckZ;
            double lim = stuckDistance.get();
            if (dx * dx + dy * dy + dz * dz > lim * lim) {
                resetStuck();
            } else if (++stuckTicks >= stuckSeconds.get() * 20) {
                info("Dung yen qua %d giay (co the bi ket), /rtp.", stuckSeconds.get());
                startRtp("dung yen qua lau");
                return;
            }
        }

        if (!baritoneMineAgain.get()) return;

        // Chong Baritone dao xuong long dat khi het cat.
        if (maxDrop.get() > 0 && stateTicks % 10 == 0 && mineStartY - mc.player.getBlockY() > maxDrop.get()) {
            info("Baritone dao xuong sau hon %d block, dung va /rtp.", maxDrop.get());
            startRtp("dao xuong sau");
            return;
        }

        // Het cat quanh day (trong ban kinh chunk) thi /rtp. Con cat o dau do Baritone van co the toi thi khong RTP.
        if (checkEmptyWhileMining.get() && stateTicks % 40 == 0) {
            int r = emptyRadius.get();
            // Khi dang dao, cat duoi nuoc nong van dao duoc nen KHONG loai cat co nuoc phia tren.
            ScanResult res = scanChunks((mc.player.getBlockX() >> 4) - r, (mc.player.getBlockZ() >> 4) - r,
                2 * r + 1, emptyBelow.get(), false);
            if (res.sand() < emptyBelow.get()) {
                if (++emptyChecks >= 2) {
                    info("Het cat trong %d chunk quanh day (con %d). Dung Baritone va /rtp.", r, res.sand());
                    startRtp("het cat quanh day");
                    return;
                }
            } else {
                emptyChecks = 0;
            }
        }

        // Sau khi bo qua tin "het cat" (ngap nuoc): cho len khoi nuoc roi bao Baritone dao lai.
        if (remineWait > 0 && --remineWait == 0) {
            if (mc.player.isTouchingWater() && ++remineTries < 15) {
                remineWait = 20;
            } else {
                Block[] blocks = targetBlocks.get().toArray(new Block[0]);
                if (blocks.length > 0) PathManagers.get().mine(blocks);
                idleTicks = 0;
            }
        }

        if (PathManagers.get().isPathing()) {
            idleTicks = 0;
            return;
        }
        // Baritone vua bao "blacklisting": no dang tinh lai duong de dao block khac, chua phai dung han.
        if (blacklistGrace > 0) {
            blacklistGrace--;
            idleTicks = 0;
            return;
        }
        // Baritone dung han thi /rtp.
        if (++idleTicks >= baritoneIdleTicks.get()) {
            info("Baritone da dung dao, /rtp.");
            startRtp("Baritone dung");
        }
    }

    /** Con du cat (tinh ca cat duoi nuoc) trong ban kinh het-cat khong. */
    private boolean stillHasSand() {
        int r = emptyRadius.get();
        ScanResult res = scanChunks((mc.player.getBlockX() >> 4) - r, (mc.player.getBlockZ() >> 4) - r,
            2 * r + 1, emptyBelow.get(), false);
        return res.sand() >= emptyBelow.get();
    }

    private void ensureShovel() {
        if (mc.currentScreen != null) return;
        if (mc.player.getMainHandStack().isIn(ItemTags.SHOVELS)) return;

        BlockState sand = Blocks.SAND.getDefaultState();
        int best = -1;
        float bestSpeed = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (st.isEmpty() || !st.isIn(ItemTags.SHOVELS)) continue;
            float sp = st.getMiningSpeedMultiplier(sand);
            if (best < 0 || sp > bestSpeed) {
                best = i;
                bestSpeed = sp;
            }
        }

        if (best >= 0) {
            InvUtils.swap(best, false);
            dbg("Cam lai xeng o slot hotbar " + best);
        } else if (mc.player.getOffHandStack().isIn(ItemTags.SHOVELS)) {
            // Xeng dang o tay trai (luc sua Mending): doi tay de lay ra.
            swapOffhand();
            dbg("Xeng dang o tay trai, doi tay de cam lai.");
        } else if (!warnedNoShovel) {
            warnedNoShovel = true;
            warning("Khong thay xeng trong hotbar, dang dao bang tay.");
        }
    }

    private void swapOffhand() {
        if (mc.getNetworkHandler() == null) return;
        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
            PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
    }

    // ---------------------------------------------------------------- ban / mua XP / sua xeng

    private boolean isJobState() {
        return state == State.SELL || state == State.BUY_XP || state == State.REPAIR;
    }

    private int freeSlotCount() {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).isEmpty()) n++;
        }
        return n;
    }

    private int sellableCount() {
        List<Item> items = sellItems.get();
        int n = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (!st.isEmpty() && items.contains(st.getItem())) n += st.getCount();
        }
        return n;
    }

    private int xpCount() {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (st.isOf(Items.EXPERIENCE_BOTTLE)) n += st.getCount();
        }
        return n;
    }

    private boolean shouldSell() {
        return freeSlotCount() <= sellFreeSlots.get() && sellableCount() >= minSell.get();
    }

    private static float percent(ItemStack st) {
        int max = st.getMaxDamage();
        if (max <= 0) return 100f;
        return 100f * (max - st.getDamage()) / max;
    }

    /** O hotbar co xeng can sua (con <= sua-khi-con-phan-tram), chon cai thap nhat. -1 neu khong co. */
    private int findShovelToRepair() {
        int best = -1;
        float bestPct = 101f;
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (st.isEmpty() || !st.isIn(ItemTags.SHOVELS) || st.getMaxDamage() <= 0) continue;
            float pct = percent(st);
            if (pct <= repairBelow.get() && pct < bestPct) {
                best = i;
                bestPct = pct;
            }
        }
        return best;
    }

    private void checkJobs() {
        if (autoRepair.get()) {
            int home = findShovelToRepair();
            if (home >= 0) {
                info("Xeng con %d%%, can sua.", Math.round(percent(mc.player.getInventory().getStack(home))));
                if (xpCount() > 0) {
                    startRepair(home);
                } else if (freeSlotCount() > 0) {
                    startBuy(home);
                } else if (autoSell.get() && sellableCount() > 0) {
                    startSell(true);
                } else {
                    warning("Tui day va khong co gi de ban, khong mua duoc XP.");
                    jobCooldown = 1200;
                }
                return;
            }
        }
        if (autoSell.get() && shouldSell()) startSell(false);
    }

    // ---- ban

    public void requestSell() {
        if (mc.player == null || state != State.MINING) {
            warning("Chi ban duoc khi dang o trang thai dao (MINING).");
            return;
        }
        startSell(false);
    }

    private void startSell(boolean repairAfter) {
        pauseOthers();
        closeScreen();
        repairAfterSell = repairAfter;
        script = parseScript(sellScript.get());
        stepIdx = 0;
        stepTicks = 0;
        sellCountBefore = sellableCount();
        sellRounds++;
        state = State.SELL;
        stateTicks = 0;
        wait = dumpDelay();
        info("Bat dau ban vao order (%d item).", sellCountBefore);
    }

    private void tickSell() {
        if (!stepScript()) return;
        closeScreen();

        int after = sellableCount();
        if (after >= sellCountBefore) {
            abortJob("Khong ban duoc item nao (order het/het tien, hoac script-ban sai).");
            return;
        }
        info("Da ban %d item.", sellCountBefore - after);
        jobFailures = 0;

        if (shouldSell() && sellRounds < maxSellRounds.get()) {
            startSell(repairAfterSell);
            return;
        }
        if (repairAfterSell && autoRepair.get()) {
            int home = findShovelToRepair();
            if (home >= 0) {
                if (xpCount() > 0) startRepair(home);
                else if (freeSlotCount() > 0) startBuy(home);
                else abortJob("Ban xong nhung tui van day, khong mua duoc XP.");
                return;
            }
        }
        finishJob();
    }

    // ---- mua XP

    private void startBuy(int home) {
        repairHome = home;
        if (++buyRounds > maxBuys.get()) {
            abortJob("Da mua XP qua so lan toi da ma xeng van chua du.");
            return;
        }
        pauseOthers();
        closeScreen();
        buyDone = 0;
        buyTarget = Math.max(1, Math.min(buyRuns.get(), freeSlotCount()));
        state = State.BUY_XP;
        stateTicks = 0;
        startBuyScript();
        info("Mua XP (%d stack).", buyTarget);
    }

    private void startBuyScript() {
        script = parseScript(buyScript.get());
        stepIdx = 0;
        stepTicks = 0;
        wait = dumpDelay();
    }

    private void tickBuy() {
        if (!stepScript()) return;
        closeScreen();
        buyDone++;
        if (buyDone < buyTarget) {
            startBuyScript();
            wait = dumpDelay() * 2;
            return;
        }
        if (xpCount() == 0) {
            abortJob("Chay xong script-mua-xp nhung khong co binh XP trong tui.");
            return;
        }
        info("Da mua XP, co %d binh.", xpCount());
        startRepair(repairHome);
    }

    // ---- sua xeng

    public void requestRepair() {
        if (mc.player == null || state != State.MINING) {
            warning("Chi sua duoc khi dang o trang thai dao (MINING).");
            return;
        }
        int home = -1;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isIn(ItemTags.SHOVELS)) {
                home = i;
                break;
            }
        }
        if (home < 0) {
            error("Khong thay xeng trong hotbar.");
            return;
        }
        if (xpCount() > 0) startRepair(home);
        else if (freeSlotCount() > 0) startBuy(home);
        else error("Tui day, khong mua duoc XP.");
    }

    private void startRepair(int home) {
        repairHome = home;
        pauseOthers();
        closeScreen();
        rphase = RPhase.SELECT;
        state = State.REPAIR;
        stateTicks = 0;
        repairStartDamage = mc.player.getInventory().getStack(home).getDamage();
        wait = dumpDelay();
        dbg("Bat dau sua xeng o hotbar " + home);
    }

    private void tickRepair() {
        stateTicks++;
        switch (rphase) {
            case SELECT -> {
                ItemStack st = mc.player.getInventory().getStack(repairHome);
                if (!st.isIn(ItemTags.SHOVELS)) {
                    abortJob("Xeng khong con o hotbar " + (repairHome + 1) + ".");
                    return;
                }
                InvUtils.swap(repairHome, false);
                rphase = RPhase.TO_OFFHAND;
                wait = dumpDelay();
            }
            case TO_OFFHAND -> {
                swapOffhand();
                shovelInOffhand = true;
                rphase = RPhase.PICK_XP;
                wait = dumpDelay() + 6; // cho server dong bo
            }
            case PICK_XP -> {
                if (!mc.player.getOffHandStack().isIn(ItemTags.SHOVELS)) {
                    shovelInOffhand = false;
                    abortJob("Khong dua duoc xeng sang tay trai.");
                    return;
                }
                int slot = pickHotbarSlotForXp();
                if (slot < 0) { // het binh XP
                    rphase = RPhase.WAIT_ORBS;
                    wait = orbWait.get();
                    return;
                }
                InvUtils.swap(slot, false);
                rphase = RPhase.AIM;
                wait = dumpDelay();
            }
            case AIM -> {
                if (!aimPitch(85f)) { // xoay muot nhin xuong chan
                    wait = 1;
                    return;
                }
                rphase = RPhase.THROW;
                wait = 2;
            }
            case THROW -> {
                if (percent(mc.player.getOffHandStack()) >= repairTo.get()) {
                    rphase = RPhase.WAIT_ORBS;
                    wait = orbWait.get();
                    return;
                }
                if (!mc.player.getMainHandStack().isOf(Items.EXPERIENCE_BOTTLE)) {
                    rphase = RPhase.PICK_XP;
                    return;
                }
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.swingHand(Hand.MAIN_HAND);
                wait = human(throwDelay.get() + (randomDelay.get() > 0 ? ThreadLocalRandom.current().nextInt(randomDelay.get() + 1) : 0));
            }
            case WAIT_ORBS -> {
                float pct = percent(mc.player.getOffHandStack());
                repairOk = pct >= repairTo.get();
                if (repairOk) info("Da sua xeng len %d%%.", Math.round(pct));
                rphase = RPhase.RESTORE;
            }
            case RESTORE -> {
                InvUtils.swap(repairHome, false);
                swapOffhand();
                shovelInOffhand = false;
                rphase = RPhase.DONE;
                wait = dumpDelay() + 6;
            }
            case DONE -> afterRepair();
        }
    }

    private void afterRepair() {
        if (repairOk) {
            finishJob();
            return;
        }
        ItemStack st = mc.player.getInventory().getStack(repairHome);
        if (st.getDamage() >= repairStartDamage) {
            jobsDisabled = true;
            abortJob("Nem XP xong ma do ben xeng khong tang. Xeng co Mending khong? Da tat tu dong sua cho toi khi bat lai module.");
            return;
        }
        if (freeSlotCount() == 0) {
            abortJob("Xeng chua du % nhung tui day, khong mua them XP duoc.");
            return;
        }
        startBuy(repairHome); // chua du: mua them (co gioi han so lan)
    }

    /** Dua binh XP vao hotbar (khac o chua xeng) va tra ve chi so hotbar. -1 neu het binh. */
    private int pickHotbarSlotForXp() {
        for (int i = 0; i < 9; i++) {
            if (i != repairHome && mc.player.getInventory().getStack(i).isOf(Items.EXPERIENCE_BOTTLE)) return i;
        }
        for (int inv = 9; inv < 36; inv++) {
            if (!mc.player.getInventory().getStack(inv).isOf(Items.EXPERIENCE_BOTTLE)) continue;
            int target = -1;
            for (int i = 0; i < 9; i++) {
                if (i != repairHome && mc.player.getInventory().getStack(i).isEmpty()) {
                    target = i;
                    break;
                }
            }
            if (target < 0) target = repairHome == 0 ? 1 : 0;
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, inv, target, SlotActionType.SWAP, mc.player);
            return target;
        }
        return -1;
    }

    private boolean aimPitch(float target) {
        float cur = mc.player.getPitch();
        float diff = target - cur;
        if (Math.abs(diff) < 1f) return true;
        float step = 6f + ThreadLocalRandom.current().nextFloat() * 6f;
        mc.player.setPitch(cur + Math.max(-step, Math.min(step, diff)));
        return false;
    }

    private void restoreShovelIfNeeded() {
        if (shovelInOffhand && mc.player != null && mc.player.getOffHandStack().isIn(ItemTags.SHOVELS)) {
            InvUtils.swap(repairHome, false);
            swapOffhand();
        }
        shovelInOffhand = false;
    }

    private void finishJob() {
        sellRounds = 0;
        buyRounds = 0;
        jobFailures = 0;
        resumeOthers();
        state = State.MINING;
        stateTicks = 0;
        idleTicks = 0;
        busyGrace = 100;
        jobCooldown = 200;
        resetStuck();
    }

    private void abortJob(String msg) {
        closeScreen();
        restoreShovelIfNeeded();
        script.clear();
        jobFailures++;
        warning("%s", msg);
        sellRounds = 0;
        buyRounds = 0;
        resumeOthers();
        state = State.MINING;
        stateTicks = 0;
        idleTicks = 0;
        busyGrace = 100;
        jobCooldown = 600;
        resetStuck();
        if (jobFailures >= 3 && !jobsDisabled) {
            jobsDisabled = true;
            warning("Loi %d lan lien tiep, tam tat tu dong ban/sua xeng cho toi khi bat lai module.", jobFailures);
        }
    }

    /** Co nguoi choi/nguy hiem luc dang ban/mua/sua: bo dang, tra xeng ve tay roi de logic RTP lo tiep. */
    private void leaveJobForDanger() {
        closeScreen();
        restoreShovelIfNeeded();
        script.clear();
        sellRounds = 0;
        buyRounds = 0;
        state = State.MINING;
    }

    private void resetStuck() {
        stuckTicks = 0;
        if (mc.player != null) {
            stuckX = mc.player.getX();
            stuckY = mc.player.getY();
            stuckZ = mc.player.getZ();
        }
    }

    /** Dang an / dung item (ke ca Auto Eat cua Meteor): cac viec khac phai nhuong, khong coi la het cat hay ket. */
    private boolean otherBusy() {
        if (mc.player != null && mc.player.isUsingItem()) return true;
        return autoEatEating();
    }

    private Field eatingField;
    private boolean eatingLookedUp;

    /** Doc co "eating" cua Auto Eat (Meteor) bang reflection de khong phu thuoc ten ham/truong luc bien dich. */
    private boolean autoEatEating() {
        Module m = Modules.get().get("auto-eat");
        if (m == null || !m.isActive()) return false;
        try {
            if (!eatingLookedUp) {
                eatingLookedUp = true;
                try { eatingField = m.getClass().getField("eating"); } catch (Throwable ignored) { eatingField = null; }
            }
            return eatingField != null && eatingField.getBoolean(m);
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean isOcean() {
        BlockPos p = mc.player.getBlockPos();
        return mc.world.getBiome(p).isIn(BiomeTags.IS_OCEAN);
    }

    /** Quet vung N x N chunk quanh ban, chi dem block dao duoc. */
    private ScanResult scan() {
        int px = mc.player.getBlockX();
        int pz = mc.player.getBlockZ();
        int pcx = px >> 4;
        int pcz = pz >> 4;
        int n = areaSize.get();

        int sx;
        int sz;
        if (n == 1) {
            sx = pcx;
            sz = pcz;
        } else if (n == 2) {
            // 4 chunk sat ban nhat: lay chunk dang dung + chunk ben canh o phia ban dang dung gan
            sx = pcx + ((px & 15) < 8 ? -1 : 0);
            sz = pcz + ((pz & 15) < 8 ? -1 : 0);
        } else {
            sx = pcx - 1;
            sz = pcz - 1;
        }
        return scanChunks(sx, sz, n, 0, skipUnderwater.get());
    }

    /** Quet n x n chunk bat dau tai (sx, sz). limit > 0: dung som khi dem du limit block. */
    private ScanResult scanChunks(int sx, int sz, int n, int limit, boolean skipWater) {
        Set<Block> targets = new HashSet<>(targetBlocks.get());
        Predicate<BlockState> pred = s -> targets.contains(s.getBlock());

        int py = mc.player.getBlockY();
        int dyMax = maxDy.get();
        int bottom = mc.world.getBottomSectionCoord();
        BlockPos.Mutable above = new BlockPos.Mutable();

        int count = 0;
        int hidden = 0;
        boolean allLoaded = true;

        outer:
        for (int cx = sx; cx < sx + n; cx++) {
            for (int cz = sz; cz < sz + n; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) {
                    allLoaded = false;
                    continue;
                }

                ChunkSection[] sections = chunk.getSectionArray();
                for (int i = 0; i < sections.length; i++) {
                    ChunkSection sec = sections[i];
                    if (sec == null || sec.isEmpty()) continue;
                    if (!sec.getBlockStateContainer().hasAny(pred)) continue;

                    int baseY = (bottom + i) << 4;
                    if (Math.abs(baseY + 8 - py) > dyMax + 16) continue;

                    for (int x = 0; x < 16; x++) {
                        for (int y = 0; y < 16; y++) {
                            int wy = baseY + y;
                            if (Math.abs(wy - py) > dyMax) continue;
                            for (int z = 0; z < 16; z++) {
                                if (!pred.test(sec.getBlockState(x, y, z))) continue;
                                if (exposedOnly.get() && !isExposed((cx << 4) + x, wy, (cz << 4) + z)) continue;

                                if (skipWater) {
                                    above.set((cx << 4) + x, wy + 1, (cz << 4) + z);
                                    if (!mc.world.getFluidState(above).isEmpty()) {
                                        hidden++;
                                        continue;
                                    }
                                }
                                count++;
                                if (limit > 0 && count >= limit) break outer;
                            }
                        }
                    }
                }
            }
        }

        return new ScanResult(count, hidden, allLoaded, n * n);
    }

    // ---------------------------------------------------------------- tam dung / khoi phuc

    private void pauseOthers() {
        // PAUSE Baritone (khong stop/cancel), xong thi resume.
        if (stopBaritone.get() && !baritonePaused) {
            try {
                if (PathManagers.get().isPathing()) {
                    PathManagers.get().pause();
                    baritonePaused = true;
                }
            } catch (Throwable ignored) { }
        }
        for (Module m : pauseModules.get()) {
            if (m != null && m != this && m.isActive() && !pausedModules.contains(m)) {
                m.toggle();
                pausedModules.add(m);
            }
        }
    }

    private void resumeOthers() {
        if (baritonePaused) {
            try { PathManagers.get().resume(); } catch (Throwable ignored) { }
            baritonePaused = false;
        }
        for (Module m : pausedModules) {
            if (!m.isActive()) m.toggle();
        }
        pausedModules.clear();
    }

    // ---------------------------------------------------------------- loi

    private void fail(String msg) {
        if (isJobState()) {
            abortJob(msg);
            return;
        }
        errors++;
        closeScreen();
        if (errors >= maxErrors.get()) {
            error("Loi %d lan lien tiep, tat rtp-helper. %s", errors, msg);
            info("Nuker/Baritone da duoc dung lai. Sua loi roi bat lai bang tay.");
            resumeOthers();
            try { PathManagers.get().stop(); } catch (Throwable ignored) { }
            toggle();
            return;
        }
        info("RTP that bai: %s Thu lai sau %d tick.", msg, retryWait.get());
        state = State.RTP_COOLDOWN;
        wait = retryWait.get();
    }

    private void dbg(String s) {
        if (debug.get()) info("[debug] %s", s);
    }

    // ---------------------------------------------------------------- tien ich

    private int nextDelay() {
        int extra = randomDelay.get();
        return human(stepDelay.get() + (extra > 0 ? ThreadLocalRandom.current().nextInt(extra + 1) : 0));
    }

    /** Do tre (tick) co phan bo tu nhien quanh base, thinh thoang do du, cham dan khi chay lau. */
    private int human(int base) {
        if (!humanMode.get()) return base;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double v = base * Math.exp(r.nextGaussian() * 0.30);
        v = Math.max(base * 0.6, Math.min(base * 2.5, v));
        if (hesitateChance.get() > 0 && r.nextInt(100) < hesitateChance.get()) v += 15 + r.nextInt(30);
        if (fatigue.get()) {
            double hours = (System.currentTimeMillis() - activatedAt) / 3_600_000.0;
            v *= 1.0 + Math.min(0.25, hours * 0.08);
        }
        return Math.max(1, (int) Math.round(v));
    }

    /** Thoi gian phan xa cua nguoi that khi menu vua hien ra (khoang 0,3-0,9 giay). */
    private int reactionTicks() {
        return humanMode.get() ? human(10) : 0;
    }

    private static String norm(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.replace('\u0111', 'd').replace('\u0110', 'D').toLowerCase();
    }

    private int parseCooldownTicks(String msg) {
        Matcher m = Pattern.compile("(\\d+)").matcher(msg);
        if (!m.find()) return retryWait.get();
        int v = Integer.parseInt(m.group(1));
        if (msg.contains("phut") || msg.contains("minute")) v *= 60;
        return Math.max(20, v * 20 + 20);
    }

    private List<Step> parseScript(List<String> lines) {
        List<Step> out = new ArrayList<>();
        for (String raw : lines) {
            String line = raw == null ? "" : raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;

            Step s = new Step();
            s.raw = line;
            if (line.startsWith("?")) {
                s.optional = true;
                line = line.substring(1).trim();
            }
            int amp = line.indexOf('&'); // "& any" = bat ky item nao cung duoc
            if (amp >= 0) line = line.substring(0, amp).trim();

            String[] p = line.split("\\s+", 2);
            String cmd = p[0].toLowerCase();
            String arg = p.length > 1 ? p[1].trim() : "";

            try {
                switch (cmd) {
                    case "wait" -> {
                        s.kind = Kind.WAIT;
                        s.num = Integer.parseInt(arg);
                    }
                    case "cmd" -> {
                        s.kind = Kind.CMD;
                        s.arg = arg;
                    }
                    case "waitgui" -> s.kind = Kind.WAITGUI;
                    case "close" -> s.kind = Kind.CLOSE;
                    case "click" -> {
                        s.kind = Kind.CLICK;
                        if (arg.startsWith("slot:")) {
                            s.bySlot = true;
                            s.slot = Integer.parseInt(arg.substring(5).trim());
                        } else if (arg.startsWith("id:")) {
                            s.id = arg.substring(3).trim().toLowerCase();
                        } else {
                            throw new IllegalArgumentException("click can slot:N hoac id:xxx");
                        }
                    }
                    default -> throw new IllegalArgumentException("lenh la: " + cmd);
                }
                out.add(s);
            } catch (Exception e) {
                warning("Bo qua dong script khong hop le '%s' (%s)", s.raw, e.getMessage());
            }
        }
        return out;
    }
}
