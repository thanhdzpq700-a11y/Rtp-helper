package com.rtphelper.modules;

import com.rtphelper.RtpHelperAddon;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ModuleListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.world.Nuker;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * RTP Helper: chi lo phan RTP.
 *
 * Vong lap:
 *  - Bat module / sau moi lan /rtp: cho chunk load, quet vung chunk (mac dinh 2x2) dem cat dao duoc.
 *  - Duoi nguong (mac dinh 30) hoac dang o bien: /rtp tiep.
 *  - Du cat: bat lai Nuker (neu bi tam dung) va cho Baritone mine block-can-dao.
 *  - Baritone dang dao thi KHONG /rtp du quet khong thay cat. Chi khi Baritone dung han thi /rtp.
 */
public class RtpHelper extends Module {

    private enum State {
        RTP_SCRIPT,        // dang chay script-rtp (/rtp, click menu)
        RTP_WAIT_TP,       // cho duoc dich chuyen
        RTP_COOLDOWN,      // server cooldown / loi, cho roi thu lai
        WAIT_CHUNKS,       // da dich chuyen, cho chunk load roi quet cat
        MINING             // Baritone dang dao
    }

    private enum Kind { WAIT, CMD, WAITGUI, CLICK, CLOSE }

    private static final class Step {
        Kind kind;
        int num;            // WAIT: so tick
        String arg;         // CMD: lenh
        boolean bySlot;     // CLICK: slot:N hay id:xxx
        int slot;
        String id;
        boolean optional;   // buoc co dau ?
        String raw;
    }

    private record ScanResult(int sand, int hidden, boolean allLoaded, int chunks) {}

    // ---------------------------------------------------------------- settings

    private final SettingGroup sgGeneral = settings.createGroup("Chung");
    private final SettingGroup sgRtp = settings.createGroup("RTP");
    private final SettingGroup sgAdvanced = settings.createGroup("Nang cao");
    private final SettingGroup sgScript = settings.createGroup("Script");

    // Chung
    private final Setting<Boolean> baritoneMineAgain = sgGeneral.add(new BoolSetting.Builder()
        .name("baritone-dao-lai")
        .description("Sau RTP thay du cat thi bat lai Baritone mine block-can-dao. Tat di thi khong theo doi duoc Baritone dung.")
        .defaultValue(true)
        .build());

    private final Setting<List<Module>> pauseModules = sgGeneral.add(new ModuleListSetting.Builder()
        .name("tam-dung-module")
        .description("Module tam tat khi dang /rtp, xong thi bat lai (mac dinh: Nuker).")
        .defaultValue(Nuker.class)
        .build());

    private final Setting<Boolean> stopBaritone = sgGeneral.add(new BoolSetting.Builder()
        .name("tam-dung-baritone")
        .description("Dung Baritone khi dang /rtp.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> runUnfocused = sgGeneral.add(new BoolSetting.Builder()
        .name("chay-khi-alt-tab")
        .description("Alt-tab ra ngoai van chay: game khong tu mo menu pause khi mat focus.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> noCursorLock = sgGeneral.add(new BoolSetting.Builder()
        .name("khong-chiem-chuot")
        .description("Khong khoa/chiem chuot khi module dang bat. Tat di neu muon tu xoay camera.")
        .defaultValue(true)
        .build());

    // RTP
    private final Setting<List<Block>> targetBlocks = sgRtp.add(new BlockListSetting.Builder()
        .name("block-can-dao")
        .description("Block can tim sau RTP va cho Baritone dao.")
        .defaultValue(Blocks.SAND)
        .build());

    private final Setting<Integer> minBlocks = sgRtp.add(new IntSetting.Builder()
        .name("rtp-khi-con-duoi")
        .description("Vung quet co it hon bay nhieu block dao duoc thi RTP.")
        .defaultValue(30)
        .range(1, 100000)
        .sliderRange(1, 500)
        .build());

    private final Setting<Integer> areaSize = sgRtp.add(new IntSetting.Builder()
        .name("vung-quet-chunk")
        .description("Quet N x N chunk quanh ban (2 = 2x2 chunk, chon 4 chunk sat ban nhat).")
        .defaultValue(2)
        .range(1, 3)
        .sliderRange(1, 3)
        .build());

    private final Setting<Integer> maxDy = sgRtp.add(new IntSetting.Builder()
        .name("lech-do-cao-toi-da")
        .description("Chi tinh cat lech do cao (Y) so voi ban khong qua bay nhieu block.")
        .defaultValue(48)
        .range(1, 400)
        .sliderRange(8, 128)
        .build());

    private final Setting<Boolean> skipUnderwater = sgRtp.add(new BoolSetting.Builder()
        .name("bo-cat-duoi-nuoc")
        .description("Khong tinh block co nuoc/dung dich o ngay phia tren (cat o day bien, day song).")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> rtpInOcean = sgRtp.add(new BoolSetting.Builder()
        .name("rtp-khi-o-bien")
        .description("Dap xuong bien (biome ocean) hoac dang boi trong nuoc thi /rtp tiep.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> maxRtp = sgRtp.add(new IntSetting.Builder()
        .name("so-lan-rtp-toi-da")
        .description("RTP lien tiep toi da bay nhieu lan ma van khong co cat (0 = toi khi co cat).")
        .defaultValue(0)
        .range(0, 1000)
        .sliderRange(0, 100)
        .build());

    private final Setting<Integer> baritoneIdleTicks = sgRtp.add(new IntSetting.Builder()
        .name("cho-baritone-dung")
        .description("Baritone khong di chuyen/dao lien tuc bay nhieu tick thi coi nhu da het cat va /rtp (20 tick = 1 giay).")
        .defaultValue(80)
        .range(20, 1200)
        .sliderRange(20, 400)
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<List<String>> baritoneKeywords = sgRtp.add(new StringListSetting.Builder()
        .name("tu-khoa-baritone-het-cat")
        .description("Tin nhan chat cua Baritone chua cac tu nay (khong phan biet hoa thuong/dau) thi /rtp ngay.")
        .defaultValue(new ArrayList<>(List.of("no known locations", "unable to find", "khong tim thay")))
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<List<String>> cooldownKeywords = sgRtp.add(new StringListSetting.Builder()
        .name("tu-khoa-cooldown")
        .description("Tin nhan server chua cac tu nay thi coi la dang cooldown RTP, doc so giay trong tin de cho dung.")
        .defaultValue(new ArrayList<>(List.of("cooldown", "please wait", "vui long cho")))
        .build());

    // Nang cao
    private final Setting<Integer> stepDelay = sgAdvanced.add(new IntSetting.Builder()
        .name("do-tre-moi-buoc")
        .description("Tick nghi giua moi buoc/click (20 tick = 1 giay). Tang len neu lag.")
        .defaultValue(8)
        .range(1, 100)
        .sliderRange(1, 40)
        .build());

    private final Setting<Integer> randomDelay = sgAdvanced.add(new IntSetting.Builder()
        .name("do-tre-ngau-nhien")
        .description("Cong them 0..N tick ngau nhien vao moi do tre cho giong nguoi that.")
        .defaultValue(4)
        .range(0, 40)
        .sliderRange(0, 20)
        .build());

    private final Setting<Integer> menuTimeout = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-menu-toi-da")
        .description("Tick toi da cho menu/item hien ra truoc khi bao loi.")
        .defaultValue(100)
        .range(10, 600)
        .sliderRange(20, 300)
        .build());

    private final Setting<Integer> tpTimeout = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-dich-chuyen")
        .description("Sau /rtp cho toi da bay nhieu tick de duoc dich chuyen.")
        .defaultValue(200)
        .range(20, 1200)
        .sliderRange(40, 600)
        .build());

    private final Setting<Integer> chunkDelay = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-load-chunk")
        .description("Sau khi dich chuyen cho it nhat bay nhieu tick roi moi quet cat.")
        .defaultValue(40)
        .range(0, 400)
        .sliderRange(0, 200)
        .build());

    private final Setting<Integer> chunkTimeout = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-chunk-toi-da")
        .description("Cho chunk trong vung quet load toi da bay nhieu tick, qua han van chua du thi RTP lai.")
        .defaultValue(200)
        .range(20, 1200)
        .sliderRange(40, 600)
        .build());

    private final Setting<Integer> retryWait = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-rtp-lai")
        .description("/rtp khong dich chuyen (server cooldown) hoac loi thi cho bay nhieu tick roi thu lai.")
        .defaultValue(200)
        .range(20, 2400)
        .sliderRange(40, 1200)
        .build());

    private final Setting<Integer> maxErrors = sgAdvanced.add(new IntSetting.Builder()
        .name("so-loi-toi-da")
        .description("Loi lien tiep bay nhieu lan thi tat module.")
        .defaultValue(5)
        .range(1, 50)
        .sliderRange(1, 20)
        .build());

    private final Setting<Boolean> debug = sgAdvanced.add(new BoolSetting.Builder()
        .name("debug")
        .description("In tung buoc ra chat.")
        .defaultValue(false)
        .build());

    // Script
    private final Setting<List<String>> scriptRtp = sgScript.add(new StringListSetting.Builder()
        .name("script-rtp")
        .description("Cac buoc RTP (/rtp > click slot 0). Lenh: cmd /x | wait N | waitgui | click slot:N | click id:item | close. Them ? dau dong neu buoc tuy chon.")
        .defaultValue(new ArrayList<>(List.of("cmd /rtp", "click slot:0 & any")))
        .build());

    // ---------------------------------------------------------------- state

    private State state = State.WAIT_CHUNKS;
    private int stateTicks;
    private int wait;
    private int idleTicks;
    private int rtpTries;
    private int errors;

    private List<Step> script = new ArrayList<>();
    private int stepIdx;
    private int stepTicks;

    private double startX, startY, startZ;
    private RegistryKey<World> startWorld;

    private final List<Module> pausedModules = new ArrayList<>();
    private boolean startedBaritone;

    public RtpHelper() {
        super(RtpHelperAddon.CATEGORY, "rtp-helper",
            "Tu dong /rtp toi khi co cat (quet vung chunk). Baritone dung dao thi /rtp roi dao tiep.");
    }

    // ---------------------------------------------------------------- static hooks cho mixin

    public static boolean shouldRunUnfocused() {
        RtpHelper m = Modules.get().get(RtpHelper.class);
        return m != null && m.isActive() && m.runUnfocused.get();
    }

    public static boolean shouldBlockCursorLock() {
        RtpHelper m = Modules.get().get(RtpHelper.class);
        return m != null && m.isActive() && m.noCursorLock.get();
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onActivate() {
        wait = 0;
        errors = 0;
        rtpTries = 0;
        idleTicks = 0;
        pausedModules.clear();
        startedBaritone = false;
        script.clear();
        // Danh gia ngay cho dang dung: du cat thi dao luon, khong thi /rtp.
        state = State.WAIT_CHUNKS;
        stateTicks = chunkDelay.get();
    }

    @Override
    public void onDeactivate() {
        script.clear();
        if (startedBaritone) {
            try { PathManagers.get().stop(); } catch (Throwable ignored) { }
            startedBaritone = false;
        }
        resumeOthers();
    }

    @Override
    public String getInfoString() {
        return state.name();
    }

    // ---------------------------------------------------------------- public (command)

    public void requestRtp() {
        if (mc.player == null || mc.world == null) return;
        startRtp("lenh .rtphelper rtp");
    }

    public void stopAll() {
        if (!isActive()) {
            info("Khong co viec gi dang chay.");
            return;
        }
        info("Da dung.");
        toggle();
    }

    public void printStatus() {
        info("Module: %s, trang thai: %s", isActive() ? "BAT" : "TAT (bat len thi moi tu chay)", state);
        info("RTP lien tiep chua co cat: %d, loi lien tiep: %d", rtpTries, errors);
        printScan();
    }

    public void printScan() {
        if (mc.player == null || mc.world == null) return;
        ScanResult r = scan();
        info("Vung %dx%d chunk: %d block dao duoc (%d bi nuoc che), chunk load du: %s. Can >= %d.",
            areaSize.get(), areaSize.get(), r.sand(), r.hidden(), r.allLoaded() ? "co" : "chua", minBlocks.get());
        if (rtpInOcean.get()) info("O bien: %s", isOcean() ? "CO" : "khong");
    }

    // ---------------------------------------------------------------- tick

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        if (noCursorLock.get() && mc.mouse.isCursorLocked()) mc.mouse.unlockCursor();

        if (wait > 0) {
            wait--;
            return;
        }

        try {
            switch (state) {
                case RTP_SCRIPT -> runScript();
                case RTP_WAIT_TP -> tickWaitTeleport();
                case RTP_COOLDOWN -> startRtp("het cho");
                case WAIT_CHUNKS -> tickWaitChunks();
                case MINING -> tickMining();
            }
        } catch (Throwable t) {
            fail("Loi trong " + state + ": " + t);
        }
    }

    @EventHandler
    private void onMessage(ReceiveMessageEvent event) {
        if (mc.player == null) return;
        String msg = norm(event.getMessage().getString());

        if (state == State.RTP_SCRIPT || state == State.RTP_WAIT_TP) {
            for (String kw : cooldownKeywords.get()) {
                if (!kw.isBlank() && msg.contains(norm(kw))) {
                    int ticks = parseCooldownTicks(msg);
                    dbg("Server cooldown, cho " + ticks + " tick.");
                    closeScreen();
                    state = State.RTP_COOLDOWN;
                    wait = ticks;
                    return;
                }
            }
        } else if (state == State.MINING && baritoneMineAgain.get() && stateTicks > 40) {
            for (String kw : baritoneKeywords.get()) {
                if (!kw.isBlank() && msg.contains(norm(kw))) {
                    info("Baritone bao het cat, /rtp.");
                    startRtp("Baritone bao het cat");
                    return;
                }
            }
        }
    }

    // ---------------------------------------------------------------- RTP

    private void startRtp(String reason) {
        dbg("Bat dau RTP: " + reason);
        pauseOthers();

        startX = mc.player.getX();
        startY = mc.player.getY();
        startZ = mc.player.getZ();
        startWorld = mc.world.getRegistryKey();

        script = parseScript(scriptRtp.get());
        stepIdx = 0;
        stepTicks = 0;
        state = State.RTP_SCRIPT;
        stateTicks = 0;
        idleTicks = 0;
    }

    private boolean hasTeleported() {
        if (startWorld != null && !mc.world.getRegistryKey().equals(startWorld)) return true;
        double dx = mc.player.getX() - startX;
        double dy = mc.player.getY() - startY;
        double dz = mc.player.getZ() - startZ;
        return dx * dx + dy * dy + dz * dz > 64;
    }

    private void tickWaitTeleport() {
        stateTicks++;
        if (hasTeleported()) {
            closeScreen();
            errors = 0;
            state = State.WAIT_CHUNKS;
            stateTicks = 0;
            return;
        }
        if (stateTicks > tpTimeout.get()) {
            info("Chua duoc dich chuyen sau /rtp (server dang cooldown?). Thu lai sau %d tick.", retryWait.get());
            closeScreen();
            state = State.RTP_COOLDOWN;
            wait = retryWait.get();
        }
    }

    private void runScript() {
        if (hasTeleported()) { // server tp luon, khong can click menu
            finishScript();
            return;
        }
        if (stepIdx >= script.size()) {
            finishScript();
            return;
        }

        Step s = script.get(stepIdx);
        switch (s.kind) {
            case WAIT -> nextStep(s.num);
            case CMD -> {
                sendCommand(s.arg);
                nextStep(nextDelay());
            }
            case WAITGUI -> {
                if (mc.currentScreen instanceof HandledScreen<?>) nextStep(nextDelay());
                else stepTimeout(s);
            }
            case CLICK -> {
                if (!(mc.currentScreen instanceof HandledScreen<?> hs)) {
                    stepTimeout(s);
                    return;
                }
                ScreenHandler h = hs.getScreenHandler();
                int idx = findSlot(h, s);
                if (idx < 0) {
                    stepTimeout(s);
                    return;
                }
                mc.interactionManager.clickSlot(h.syncId, idx, 0, SlotActionType.PICKUP, mc.player);
                dbg("click slot " + idx);
                nextStep(nextDelay());
            }
            case CLOSE -> {
                closeScreen();
                nextStep(nextDelay());
            }
        }
    }

    private void nextStep(int delay) {
        stepIdx++;
        stepTicks = 0;
        wait = Math.max(wait, delay);
    }

    private void stepTimeout(Step s) {
        if (++stepTicks <= menuTimeout.get()) return;
        if (s.optional) {
            dbg("Bo qua buoc tuy chon: " + s.raw);
            nextStep(0);
        } else {
            fail("Het thoi gian cho buoc: " + s.raw);
        }
    }

    private void finishScript() {
        state = State.RTP_WAIT_TP;
        stateTicks = 0;
    }

    private int findSlot(ScreenHandler h, Step s) {
        if (s.bySlot) {
            if (s.slot < 0 || s.slot >= h.slots.size()) return -1;
            return h.getSlot(s.slot).getStack().isEmpty() ? -1 : s.slot;
        }
        int limit = Math.max(0, h.slots.size() - 36); // bo qua tui do nguoi choi
        for (int i = 0; i < limit; i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (st.isEmpty()) continue;
            if (Registries.ITEM.getId(st.getItem()).getPath().equals(s.id)) return i;
        }
        return -1;
    }

    private void sendCommand(String cmd) {
        if (mc.getNetworkHandler() == null) return;
        if (cmd.startsWith("/")) mc.getNetworkHandler().sendChatCommand(cmd.substring(1));
        else mc.getNetworkHandler().sendChatMessage(cmd);
        dbg("gui: " + cmd);
    }

    private void closeScreen() {
        if (mc.currentScreen != null && mc.player != null) mc.player.closeHandledScreen();
    }

    // ---------------------------------------------------------------- quet cat sau RTP

    private void tickWaitChunks() {
        stateTicks++;
        if (stateTicks < chunkDelay.get()) return;

        ScanResult r = scan();
        if (!r.allLoaded()) {
            if (stateTicks > chunkTimeout.get()) {
                notEnough("chunk chua load du sau " + stateTicks + " tick");
            }
            return;
        }

        if (rtpInOcean.get() && (mc.player.isTouchingWater() || isOcean())) {
            notEnough("dang o bien");
            return;
        }

        if (r.sand() < minBlocks.get()) {
            notEnough("chi co " + r.sand() + " block (can >= " + minBlocks.get() + ", " + r.hidden() + " bi nuoc che)");
            return;
        }

        startMining(r.sand());
    }

    private void notEnough(String reason) {
        rtpTries++;
        if (maxRtp.get() > 0 && rtpTries >= maxRtp.get()) {
            error("RTP %d lan van khong thay cat (%s). Tat module.", rtpTries, reason);
            toggle();
            return;
        }
        info("Cho moi: %s. RTP lai (lan %d).", reason, rtpTries);
        startRtp(reason);
    }

    private void startMining(int count) {
        rtpTries = 0;
        errors = 0;
        resumeOthers();

        if (baritoneMineAgain.get()) {
            Block[] blocks = targetBlocks.get().toArray(new Block[0]);
            if (blocks.length == 0) {
                error("block-can-dao dang trong, Baritone khong biet dao gi.");
                toggle();
                return;
            }
            PathManagers.get().mine(blocks);
            startedBaritone = true;
        }
        info("Thay %d block cat dao duoc. Baritone dao tiep.", count);

        state = State.MINING;
        stateTicks = 0;
        idleTicks = 0;
    }

    private void tickMining() {
        stateTicks++;
        if (!baritoneMineAgain.get()) return;
        if (stateTicks < 60) return; // cho Baritone tinh duong

        if (PathManagers.get().isPathing()) {
            idleTicks = 0;
            return;
        }
        // Baritone van dang dao thi khong RTP du quet khong thay cat: chi RTP khi Baritone dung han.
        if (++idleTicks >= baritoneIdleTicks.get()) {
            info("Baritone da dung dao, /rtp.");
            startRtp("Baritone dung");
        }
    }

    private boolean isOcean() {
        BlockPos p = mc.player.getBlockPos();
        return mc.world.getBiome(p).isIn(BiomeTags.IS_OCEAN);
    }

    /** Quet vung N x N chunk, chi dem block dao duoc. */
    private ScanResult scan() {
        Set<Block> targets = new HashSet<>(targetBlocks.get());
        Predicate<BlockState> pred = s -> targets.contains(s.getBlock());

        int px = mc.player.getBlockX();
        int py = mc.player.getBlockY();
        int pz = mc.player.getBlockZ();
        int pcx = px >> 4;
        int pcz = pz >> 4;
        int n = areaSize.get();

        int sx;
        int sz;
        if (n == 1) {
            sx = pcx;
            sz = pcz;
        } else if (n == 2) {
            // 4 chunk sat ban nhat: lay chunk dang dung + chunk ben canh o phia ban dang dung gan
            sx = pcx + ((px & 15) < 8 ? -1 : 0);
            sz = pcz + ((pz & 15) < 8 ? -1 : 0);
        } else {
            sx = pcx - 1;
            sz = pcz - 1;
        }

        int dyMax = maxDy.get();
        int bottom = mc.world.getBottomSectionCoord();
        BlockPos.Mutable above = new BlockPos.Mutable();

        int count = 0;
        int hidden = 0;
        boolean allLoaded = true;

        for (int cx = sx; cx < sx + n; cx++) {
            for (int cz = sz; cz < sz + n; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) {
                    allLoaded = false;
                    continue;
                }

                ChunkSection[] sections = chunk.getSectionArray();
                for (int i = 0; i < sections.length; i++) {
                    ChunkSection sec = sections[i];
                    if (sec == null || sec.isEmpty()) continue;
                    if (!sec.getBlockStateContainer().hasAny(pred)) continue;

                    int baseY = (bottom + i) << 4;
                    if (Math.abs(baseY + 8 - py) > dyMax + 16) continue;

                    for (int x = 0; x < 16; x++) {
                        for (int y = 0; y < 16; y++) {
                            int wy = baseY + y;
                            if (Math.abs(wy - py) > dyMax) continue;
                            for (int z = 0; z < 16; z++) {
                                if (!pred.test(sec.getBlockState(x, y, z))) continue;

                                if (skipUnderwater.get()) {
                                    above.set((cx << 4) + x, wy + 1, (cz << 4) + z);
                                    if (!mc.world.getFluidState(above).isEmpty()) {
                                        hidden++;
                                        continue;
                                    }
                                }
                                count++;
                            }
                        }
                    }
                }
            }
        }

        return new ScanResult(count, hidden, allLoaded, n * n);
    }

    // ---------------------------------------------------------------- tam dung / khoi phuc

    private void pauseOthers() {
        if (stopBaritone.get() || startedBaritone) {
            try { PathManagers.get().stop(); } catch (Throwable ignored) { }
        }
        for (Module m : pauseModules.get()) {
            if (m != null && m != this && m.isActive() && !pausedModules.contains(m)) {
                m.toggle();
                pausedModules.add(m);
            }
        }
    }

    private void resumeOthers() {
        for (Module m : pausedModules) {
            if (!m.isActive()) m.toggle();
        }
        pausedModules.clear();
    }

    // ---------------------------------------------------------------- loi

    private void fail(String msg) {
        errors++;
        closeScreen();
        if (errors >= maxErrors.get()) {
            error("Loi %d lan lien tiep, tat rtp-helper. %s", errors, msg);
            info("Nuker/Baritone da duoc dung lai. Sua loi roi bat lai bang tay.");
            try { PathManagers.get().stop(); } catch (Throwable ignored) { }
            startedBaritone = false;
            toggle();
            return;
        }
        info("RTP that bai: %s Thu lai sau %d tick.", msg, retryWait.get());
        state = State.RTP_COOLDOWN;
        wait = retryWait.get();
    }

    private void dbg(String s) {
        if (debug.get()) info("[debug] %s", s);
    }

    // ---------------------------------------------------------------- tien ich

    private int nextDelay() {
        int extra = randomDelay.get();
        return stepDelay.get() + (extra > 0 ? ThreadLocalRandom.current().nextInt(extra + 1) : 0);
    }

    private static String norm(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.replace('\u0111', 'd').replace('\u0110', 'D').toLowerCase();
    }

    private int parseCooldownTicks(String msg) {
        Matcher m = Pattern.compile("(\\d+)").matcher(msg);
        if (!m.find()) return retryWait.get();
        int v = Integer.parseInt(m.group(1));
        if (msg.contains("phut") || msg.contains("minute")) v *= 60;
        return Math.max(20, v * 20 + 20);
    }

    private List<Step> parseScript(List<String> lines) {
        List<Step> out = new ArrayList<>();
        for (String raw : lines) {
            String line = raw == null ? "" : raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;

            Step s = new Step();
            s.raw = line;
            if (line.startsWith("?")) {
                s.optional = true;
                line = line.substring(1).trim();
            }
            int amp = line.indexOf('&'); // "& any" = bat ky item nao cung duoc
            if (amp >= 0) line = line.substring(0, amp).trim();

            String[] p = line.split("\\s+", 2);
            String cmd = p[0].toLowerCase();
            String arg = p.length > 1 ? p[1].trim() : "";

            try {
                switch (cmd) {
                    case "wait" -> {
                        s.kind = Kind.WAIT;
                        s.num = Integer.parseInt(arg);
                    }
                    case "cmd" -> {
                        s.kind = Kind.CMD;
                        s.arg = arg;
                    }
                    case "waitgui" -> s.kind = Kind.WAITGUI;
                    case "close" -> s.kind = Kind.CLOSE;
                    case "click" -> {
                        s.kind = Kind.CLICK;
                        if (arg.startsWith("slot:")) {
                            s.bySlot = true;
                            s.slot = Integer.parseInt(arg.substring(5).trim());
                        } else if (arg.startsWith("id:")) {
                            s.id = arg.substring(3).trim().toLowerCase();
                        } else {
                            throw new IllegalArgumentException("click can slot:N hoac id:xxx");
                        }
                    }
                    default -> throw new IllegalArgumentException("lenh la: " + cmd);
                }
                out.add(s);
            } catch (Exception e) {
                warning("Bo qua dong script khong hop le '%s' (%s)", s.raw, e.getMessage());
            }
        }
        return out;
    }
}
