package com.rtphelper.modules;

import com.rtphelper.RtpHelperAddon;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ModuleListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.world.Nuker;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.s2c.play.OverlayMessageS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.lang.reflect.Field;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * RTP Helper: chi lo phan RTP.
 *
 * Vong lap:
 *  - Bat module / sau moi lan /rtp: cho chunk load, quet vung chunk (mac dinh 2x2) dem cat dao duoc.
 *  - Duoi nguong (mac dinh 30) hoac dang o bien: /rtp tiep.
 *  - Du cat: bat lai Nuker (neu bi tam dung) va cho Baritone mine block-can-dao.
 *  - Baritone dang dao thi KHONG /rtp du quet khong thay cat. Chi khi Baritone dung han thi /rtp.
 */
public class RtpHelper extends Module {

    private enum State {
        RTP_SCRIPT,        // dang chay script-rtp (/rtp, click menu)
        RTP_WAIT_TP,       // cho duoc dich chuyen
        RTP_COOLDOWN,      // server cooldown / loi, cho roi thu lai
        WAIT_CHUNKS,       // da dich chuyen, cho chunk load roi quet cat
        MINING             // Baritone dang dao
    }

    private enum Kind { WAIT, CMD, WAITGUI, CLICK, CLOSE }

    private static final class Step {
        Kind kind;
        int num;            // WAIT: so tick
        String arg;         // CMD: lenh
        boolean bySlot;     // CLICK: slot:N hay id:xxx
        int slot;
        String id;
        boolean optional;   // buoc co dau ?
        String raw;
    }

    private record ScanResult(int sand, int hidden, boolean allLoaded, int chunks) {}

    // ---------------------------------------------------------------- settings

    private final SettingGroup sgGeneral = settings.createGroup("Chung");
    private final SettingGroup sgRtp = settings.createGroup("RTP");
    private final SettingGroup sgAdvanced = settings.createGroup("Nang cao");
    private final SettingGroup sgScript = settings.createGroup("Script");

    // Chung
    private final Setting<Boolean> baritoneMineAgain = sgGeneral.add(new BoolSetting.Builder()
        .name("baritone-dao-lai")
        .description("Sau RTP thay du cat thi bat lai Baritone mine block-can-dao. Tat di thi khong theo doi duoc Baritone dung.")
        .defaultValue(true)
        .build());

    private final Setting<List<Module>> pauseModules = sgGeneral.add(new ModuleListSetting.Builder()
        .name("tam-dung-module")
        .description("Module tam tat khi dang /rtp, xong thi bat lai (mac dinh: Nuker).")
        .defaultValue(Nuker.class)
        .build());

    private final Setting<Boolean> stopBaritone = sgGeneral.add(new BoolSetting.Builder()
        .name("tam-dung-baritone")
        .description("Tam dung (pause) Baritone khi dang /rtp, xong thi resume. Giong Sand Helper.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> autoShovel = sgGeneral.add(new BoolSetting.Builder()
        .name("tu-cam-xeng")
        .description("Khi dang dao ma tay khong cam xeng (xeng bi ket trong hotbar) thi tu chon lai xeng tot nhat trong hotbar.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> runUnfocused = sgGeneral.add(new BoolSetting.Builder()
        .name("chay-khi-alt-tab")
        .description("Alt-tab ra ngoai van chay: game khong tu mo menu pause khi mat focus.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> noCursorLock = sgGeneral.add(new BoolSetting.Builder()
        .name("khong-chiem-chuot")
        .description("Khong khoa/chiem chuot khi module dang bat. Tat di neu muon tu xoay camera.")
        .defaultValue(true)
        .build());

    // RTP
    private final Setting<List<Block>> targetBlocks = sgRtp.add(new BlockListSetting.Builder()
        .name("block-can-dao")
        .description("Block can tim sau RTP va cho Baritone dao.")
        .defaultValue(Blocks.SAND)
        .build());

    private final Setting<Integer> minBlocks = sgRtp.add(new IntSetting.Builder()
        .name("rtp-khi-con-duoi")
        .description("Vung quet co it hon bay nhieu block dao duoc thi RTP.")
        .defaultValue(30)
        .range(1, 100000)
        .sliderRange(1, 500)
        .build());

    private final Setting<Integer> areaSize = sgRtp.add(new IntSetting.Builder()
        .name("vung-quet-chunk")
        .description("Quet N x N chunk quanh ban (2 = 2x2 chunk, chon 4 chunk sat ban nhat).")
        .defaultValue(2)
        .range(1, 3)
        .sliderRange(1, 3)
        .build());

    private final Setting<Integer> maxDy = sgRtp.add(new IntSetting.Builder()
        .name("lech-do-cao-toi-da")
        .description("Chi tinh cat lech do cao (Y) so voi ban khong qua bay nhieu block.")
        .defaultValue(48)
        .range(1, 400)
        .sliderRange(8, 128)
        .build());

    private final Setting<Boolean> skipUnderwater = sgRtp.add(new BoolSetting.Builder()
        .name("bo-cat-duoi-nuoc")
        .description("Khong tinh block co nuoc/dung dich o ngay phia tren (cat o day bien, day song).")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> checkEmptyWhileMining = sgRtp.add(new BoolSetting.Builder()
        .name("kiem-tra-het-cat-khi-dao")
        .description("Khi Baritone dang dao, dinh ky quet cat quanh ban. Het cat thi dung Baritone va /rtp (tranh Baritone dao xuong long dat).")
        .defaultValue(true)
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<Integer> emptyRadius = sgRtp.add(new IntSetting.Builder()
        .name("ban-kinh-chunk-het-cat")
        .description("Ban kinh (chunk) quet de biet con cat cho Baritone dao hay khong. Nen <= render distance.")
        .defaultValue(6)
        .range(1, 16)
        .sliderRange(1, 12)
        .visible(() -> baritoneMineAgain.get() && checkEmptyWhileMining.get())
        .build());

    private final Setting<Integer> emptyBelow = sgRtp.add(new IntSetting.Builder()
        .name("het-cat-khi-con-duoi")
        .description("Trong ban kinh tren con it hon bay nhieu block cat thi coi la het cat.")
        .defaultValue(3)
        .range(1, 1000)
        .sliderRange(1, 50)
        .visible(() -> baritoneMineAgain.get() && checkEmptyWhileMining.get())
        .build());

    private final Setting<Boolean> rtpWhenStuck = sgRtp.add(new BoolSetting.Builder()
        .name("rtp-khi-dung-yen")
        .description("Dung yen mot cho qua lau khi dang dao (Baritone ket, khong dat/dao duoc block, block ma) thi /rtp.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> stuckSeconds = sgRtp.add(new IntSetting.Builder()
        .name("thoi-gian-dung-yen")
        .description("Dung yen bao nhieu giay thi /rtp.")
        .defaultValue(60)
        .range(10, 900)
        .sliderRange(20, 300)
        .visible(rtpWhenStuck::get)
        .build());

    private final Setting<Integer> stuckDistance = sgRtp.add(new IntSetting.Builder()
        .name("khoang-cach-dung-yen")
        .description("Di chuyen it hon bay nhieu block trong khoang thoi gian tren thi tinh la dung yen.")
        .defaultValue(2)
        .range(1, 30)
        .sliderRange(1, 10)
        .visible(rtpWhenStuck::get)
        .build());

    private final Setting<Boolean> rtpLowHealth = sgRtp.add(new BoolSetting.Builder()
        .name("rtp-khi-mau-thap")
        .description("Mau xuong duoi muc phan tram ben duoi (bi quai/nguoi tan cong, ngat nuoc...) khi dang dao thi /rtp de thoat.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> lowHealthPercent = sgRtp.add(new IntSetting.Builder()
        .name("phan-tram-mau")
        .description("Muc mau toi thieu (% thanh mau). Duoi muc nay thi /rtp.")
        .defaultValue(60)
        .range(1, 99)
        .sliderRange(10, 90)
        .visible(rtpLowHealth::get)
        .build());

    private final Setting<Integer> maxDrop = sgRtp.add(new IntSetting.Builder()
        .name("do-sau-toi-da")
        .description("Ban tut xuong sau hon bay nhieu block so voi luc bat dau dao thi dung Baritone va /rtp (0 = tat).")
        .defaultValue(15)
        .range(0, 200)
        .sliderRange(0, 60)
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<Boolean> rtpInOcean = sgRtp.add(new BoolSetting.Builder()
        .name("rtp-khi-o-bien")
        .description("Dap xuong bien (biome ocean) hoac dang boi trong nuoc thi /rtp tiep.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> maxRtp = sgRtp.add(new IntSetting.Builder()
        .name("so-lan-rtp-toi-da")
        .description("RTP lien tiep toi da bay nhieu lan ma van khong co cat (0 = toi khi co cat).")
        .defaultValue(0)
        .range(0, 1000)
        .sliderRange(0, 100)
        .build());

    private final Setting<Integer> baritoneIdleTicks = sgRtp.add(new IntSetting.Builder()
        .name("cho-baritone-dung")
        .description("Baritone khong di chuyen/dao lien tuc bay nhieu tick thi coi nhu da het cat va /rtp (20 tick = 1 giay).")
        .defaultValue(80)
        .range(20, 1200)
        .sliderRange(20, 400)
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<List<String>> baritoneKeywords = sgRtp.add(new StringListSetting.Builder()
        .name("tu-khoa-baritone-het-cat")
        .description("Tin nhan chat cua Baritone chua cac tu nay (khong phan biet hoa thuong/dau) thi /rtp ngay.")
        .defaultValue(new ArrayList<>(List.of("no known locations", "unable to find", "khong tim thay")))
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<List<String>> instantKeywords = sgRtp.add(new StringListSetting.Builder()
        .name("tu-khoa-rtp-ngay")
        .description("Tin nhan (chat HOAC action bar chu do tren hotbar) chua cac tu nay thi /rtp ngay khi dang dao. Mac dinh: 'You are at a world border'.")
        .defaultValue(new ArrayList<>(List.of("world border")))
        .build());

    private final Setting<List<String>> yieldModules = sgRtp.add(new StringListSetting.Builder()
        .name("module-nhuong")
        .description("Ten module khac (vd sand-helper). Khi module do dang ban/mua/rtp (trang thai khac IDLE/COOLDOWN) thi rtp-helper khong coi Baritone dung la het cat.")
        .defaultValue(new ArrayList<>(List.of("sand-helper")))
        .visible(baritoneMineAgain::get)
        .build());

    private final Setting<List<String>> cooldownKeywords = sgRtp.add(new StringListSetting.Builder()
        .name("tu-khoa-cooldown")
        .description("Tin nhan server chua cac tu nay thi coi la dang cooldown RTP, doc so giay trong tin de cho dung.")
        .defaultValue(new ArrayList<>(List.of("cooldown", "please wait", "vui long cho")))
        .build());

    // Nang cao
    private final Setting<Integer> stepDelay = sgAdvanced.add(new IntSetting.Builder()
        .name("do-tre-moi-buoc")
        .description("Tick nghi giua moi buoc/click (20 tick = 1 giay). Tang len neu lag.")
        .defaultValue(8)
        .range(1, 100)
        .sliderRange(1, 40)
        .build());

    private final Setting<Integer> randomDelay = sgAdvanced.add(new IntSetting.Builder()
        .name("do-tre-ngau-nhien")
        .description("Cong them 0..N tick ngau nhien vao moi do tre cho giong nguoi that.")
        .defaultValue(4)
        .range(0, 40)
        .sliderRange(0, 20)
        .build());

    private final Setting<Integer> menuTimeout = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-menu-toi-da")
        .description("Tick toi da cho menu/item hien ra truoc khi bao loi.")
        .defaultValue(100)
        .range(10, 600)
        .sliderRange(20, 300)
        .build());

    private final Setting<Integer> tpTimeout = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-dich-chuyen")
        .description("Sau /rtp cho toi da bay nhieu tick de duoc dich chuyen.")
        .defaultValue(200)
        .range(20, 1200)
        .sliderRange(40, 600)
        .build());

    private final Setting<Integer> chunkDelay = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-load-chunk")
        .description("Sau khi dich chuyen cho it nhat bay nhieu tick roi moi quet cat.")
        .defaultValue(40)
        .range(0, 400)
        .sliderRange(0, 200)
        .build());

    private final Setting<Integer> chunkTimeout = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-chunk-toi-da")
        .description("Cho chunk trong vung quet load toi da bay nhieu tick, qua han van chua du thi RTP lai.")
        .defaultValue(200)
        .range(20, 1200)
        .sliderRange(40, 600)
        .build());

    private final Setting<Integer> retryWait = sgAdvanced.add(new IntSetting.Builder()
        .name("cho-rtp-lai")
        .description("/rtp khong dich chuyen (server cooldown) hoac loi thi cho bay nhieu tick roi thu lai.")
        .defaultValue(200)
        .range(20, 2400)
        .sliderRange(40, 1200)
        .build());

    private final Setting<Integer> maxErrors = sgAdvanced.add(new IntSetting.Builder()
        .name("so-loi-toi-da")
        .description("Loi lien tiep bay nhieu lan thi tat module.")
        .defaultValue(5)
        .range(1, 50)
        .sliderRange(1, 20)
        .build());

    private final Setting<Boolean> debug = sgAdvanced.add(new BoolSetting.Builder()
        .name("debug")
        .description("In tung buoc ra chat.")
        .defaultValue(false)
        .build());

    // Script
    private final Setting<List<String>> scriptRtp = sgScript.add(new StringListSetting.Builder()
        .name("script-rtp")
        .description("Cac buoc RTP (/rtp > click slot 0). Lenh: cmd /x | wait N | waitgui | click slot:N | click id:item | close. Them ? dau dong neu buoc tuy chon.")
        .defaultValue(new ArrayList<>(List.of("cmd /rtp", "click slot:0 & any")))
        .build());

    // ---------------------------------------------------------------- state

    private State state = State.WAIT_CHUNKS;
    private int stateTicks;
    private int wait;
    private int idleTicks;
    private int emptyChecks;
    private int busyGrace;
    private int stuckTicks;
    private int healthCooldown;
    private boolean warnedNoShovel;
    private double stuckX, stuckY, stuckZ;
    private volatile String pendingRtp;
    private int mineStartY;
    private int rtpTries;
    private int errors;

    private List<Step> script = new ArrayList<>();
    private int stepIdx;
    private int stepTicks;

    private double startX, startY, startZ;
    private RegistryKey<World> startWorld;

    private final List<Module> pausedModules = new ArrayList<>();
    private boolean baritonePaused;

    public RtpHelper() {
        super(RtpHelperAddon.CATEGORY, "rtp-helper",
            "Tu dong /rtp toi khi co cat (quet vung chunk). Baritone dung dao thi /rtp roi dao tiep.");
    }

    // ---------------------------------------------------------------- static hooks cho mixin

    public static boolean shouldRunUnfocused() {
        RtpHelper m = Modules.get().get(RtpHelper.class);
        return m != null && m.isActive() && m.runUnfocused.get();
    }

    public static boolean shouldBlockCursorLock() {
        RtpHelper m = Modules.get().get(RtpHelper.class);
        return m != null && m.isActive() && m.noCursorLock.get();
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onActivate() {
        wait = 0;
        errors = 0;
        rtpTries = 0;
        idleTicks = 0;
        pausedModules.clear();
        baritonePaused = false;
        healthCooldown = 0;
        pendingRtp = null;
        script.clear();
        // Danh gia ngay cho dang dung: du cat thi dao luon, khong thi /rtp.
        state = State.WAIT_CHUNKS;
        stateTicks = chunkDelay.get();
    }

    @Override
    public void onDeactivate() {
        script.clear();
        resumeOthers();
    }

    @Override
    public String getInfoString() {
        return state.name();
    }

    // ---------------------------------------------------------------- public (command)

    public void requestRtp() {
        if (mc.player == null || mc.world == null) return;
        startRtp("lenh .rtphelper rtp");
    }

    public void stopAll() {
        if (!isActive()) {
            info("Khong co viec gi dang chay.");
            return;
        }
        info("Da dung.");
        toggle();
    }

    public void printStatus() {
        info("Module: %s, trang thai: %s", isActive() ? "BAT" : "TAT (bat len thi moi tu chay)", state);
        info("RTP lien tiep chua co cat: %d, loi lien tiep: %d", rtpTries, errors);
        printScan();
    }

    public void printScan() {
        if (mc.player == null || mc.world == null) return;
        ScanResult r = scan();
        info("Vung %dx%d chunk: %d block dao duoc (%d bi nuoc che), chunk load du: %s. Can >= %d.",
            areaSize.get(), areaSize.get(), r.sand(), r.hidden(), r.allLoaded() ? "co" : "chua", minBlocks.get());
        if (rtpInOcean.get()) info("O bien: %s", isOcean() ? "CO" : "khong");
    }

    // ---------------------------------------------------------------- tick

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        if (noCursorLock.get() && mc.mouse.isCursorLocked()) mc.mouse.unlockCursor();

        // Yeu cau RTP tu chat Baritone: xu ly o tick sau, khong stop Baritone ngay trong luc no dang tick.
        if (pendingRtp != null) {
            String reason = pendingRtp;
            pendingRtp = null;
            if (state == State.MINING && !otherBusy()) {
                info("%s, /rtp.", reason);
                startRtp(reason);
                return;
            }
        }

        if (wait > 0) {
            wait--;
            return;
        }

        try {
            switch (state) {
                case RTP_SCRIPT -> runScript();
                case RTP_WAIT_TP -> tickWaitTeleport();
                case RTP_COOLDOWN -> startRtp("het cho");
                case WAIT_CHUNKS -> tickWaitChunks();
                case MINING -> tickMining();
            }
        } catch (Throwable t) {
            fail("Loi trong " + state + ": " + t);
        }
    }

    @EventHandler
    private void onMessage(ReceiveMessageEvent event) {
        if (mc.player == null) return;
        String msg = norm(event.getMessage().getString());

        if (state == State.MINING) checkInstant(msg);

        if (state == State.RTP_SCRIPT || state == State.RTP_WAIT_TP) {
            for (String kw : cooldownKeywords.get()) {
                if (!kw.isBlank() && msg.contains(norm(kw))) {
                    int ticks = parseCooldownTicks(msg);
                    dbg("Server cooldown, cho " + ticks + " tick.");
                    closeScreen();
                    state = State.RTP_COOLDOWN;
                    wait = ticks;
                    return;
                }
            }
        } else if (state == State.MINING && baritoneMineAgain.get() && stateTicks > 40) {
            for (String kw : baritoneKeywords.get()) {
                if (!kw.isBlank() && msg.contains(norm(kw))) {
                    // KHONG stop Baritone o day: tin nhan nay do Baritone in ra giua luc no dang tick,
                    // stop luc do se lam Baritone crash (NullPointerException trong MineProcess).
                    pendingRtp = "Baritone bao het cat";
                    return;
                }
            }
        }
    }

    /** Action bar (chu do tren hotbar) khong di qua chat, nen doc rieng tu goi OverlayMessage. */
    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (!(event.packet instanceof OverlayMessageS2CPacket p)) return;
        if (state != State.MINING) return;
        checkInstant(norm(p.text().getString()));
    }

    private void checkInstant(String normalizedMsg) {
        for (String kw : instantKeywords.get()) {
            if (!kw.isBlank() && normalizedMsg.contains(norm(kw))) {
                // Dat co, tick sau moi xu ly (khong stop Baritone trong luc dang xu ly goi tin/chat).
                pendingRtp = "Gap tin nhan '" + kw.trim() + "'";
                return;
            }
        }
    }

    // ---------------------------------------------------------------- RTP

    private void startRtp(String reason) {
        dbg("Bat dau RTP: " + reason);
        pendingRtp = null;
        pauseOthers();

        startX = mc.player.getX();
        startY = mc.player.getY();
        startZ = mc.player.getZ();
        startWorld = mc.world.getRegistryKey();

        script = parseScript(scriptRtp.get());
        stepIdx = 0;
        stepTicks = 0;
        state = State.RTP_SCRIPT;
        stateTicks = 0;
        idleTicks = 0;
    }

    private boolean hasTeleported() {
        if (startWorld != null && !mc.world.getRegistryKey().equals(startWorld)) return true;
        double dx = mc.player.getX() - startX;
        double dy = mc.player.getY() - startY;
        double dz = mc.player.getZ() - startZ;
        return dx * dx + dy * dy + dz * dz > 64;
    }

    private void tickWaitTeleport() {
        stateTicks++;
        if (hasTeleported()) {
            closeScreen();
            errors = 0;
            state = State.WAIT_CHUNKS;
            stateTicks = 0;
            return;
        }
        if (stateTicks > tpTimeout.get()) {
            info("Chua duoc dich chuyen sau /rtp (server dang cooldown?). Thu lai sau %d tick.", retryWait.get());
            closeScreen();
            state = State.RTP_COOLDOWN;
            wait = retryWait.get();
        }
    }

    private void runScript() {
        if (hasTeleported()) { // server tp luon, khong can click menu
            finishScript();
            return;
        }
        if (stepIdx >= script.size()) {
            finishScript();
            return;
        }

        Step s = script.get(stepIdx);
        switch (s.kind) {
            case WAIT -> nextStep(s.num);
            case CMD -> {
                sendCommand(s.arg);
                nextStep(nextDelay());
            }
            case WAITGUI -> {
                if (mc.currentScreen instanceof HandledScreen<?>) nextStep(nextDelay());
                else stepTimeout(s);
            }
            case CLICK -> {
                if (!(mc.currentScreen instanceof HandledScreen<?> hs)) {
                    stepTimeout(s);
                    return;
                }
                ScreenHandler h = hs.getScreenHandler();
                int idx = findSlot(h, s);
                if (idx < 0) {
                    stepTimeout(s);
                    return;
                }
                mc.interactionManager.clickSlot(h.syncId, idx, 0, SlotActionType.PICKUP, mc.player);
                dbg("click slot " + idx);
                nextStep(nextDelay());
            }
            case CLOSE -> {
                closeScreen();
                nextStep(nextDelay());
            }
        }
    }

    private void nextStep(int delay) {
        stepIdx++;
        stepTicks = 0;
        wait = Math.max(wait, delay);
    }

    private void stepTimeout(Step s) {
        if (++stepTicks <= menuTimeout.get()) return;
        if (s.optional) {
            dbg("Bo qua buoc tuy chon: " + s.raw);
            nextStep(0);
        } else {
            fail("Het thoi gian cho buoc: " + s.raw);
        }
    }

    private void finishScript() {
        state = State.RTP_WAIT_TP;
        stateTicks = 0;
    }

    private int findSlot(ScreenHandler h, Step s) {
        if (s.bySlot) {
            if (s.slot < 0 || s.slot >= h.slots.size()) return -1;
            return h.getSlot(s.slot).getStack().isEmpty() ? -1 : s.slot;
        }
        int limit = Math.max(0, h.slots.size() - 36); // bo qua tui do nguoi choi
        for (int i = 0; i < limit; i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (st.isEmpty()) continue;
            if (Registries.ITEM.getId(st.getItem()).getPath().equals(s.id)) return i;
        }
        return -1;
    }

    private void sendCommand(String cmd) {
        if (mc.getNetworkHandler() == null) return;
        if (cmd.startsWith("/")) mc.getNetworkHandler().sendChatCommand(cmd.substring(1));
        else mc.getNetworkHandler().sendChatMessage(cmd);
        dbg("gui: " + cmd);
    }

    private void closeScreen() {
        if (mc.currentScreen != null && mc.player != null) mc.player.closeHandledScreen();
    }

    // ---------------------------------------------------------------- quet cat sau RTP

    private void tickWaitChunks() {
        stateTicks++;
        if (stateTicks < chunkDelay.get()) return;

        ScanResult r = scan();
        if (!r.allLoaded()) {
            if (stateTicks > chunkTimeout.get()) {
                notEnough("chunk chua load du sau " + stateTicks + " tick");
            }
            return;
        }

        if (rtpInOcean.get() && (mc.player.isTouchingWater() || isOcean())) {
            notEnough("dang o bien");
            return;
        }

        if (r.sand() < minBlocks.get()) {
            notEnough("chi co " + r.sand() + " block (can >= " + minBlocks.get() + ", " + r.hidden() + " bi nuoc che)");
            return;
        }

        startMining(r.sand());
    }

    private void notEnough(String reason) {
        rtpTries++;
        if (maxRtp.get() > 0 && rtpTries >= maxRtp.get()) {
            error("RTP %d lan van khong thay cat (%s). Tat module.", rtpTries, reason);
            toggle();
            return;
        }
        info("Cho moi: %s. RTP lai (lan %d).", reason, rtpTries);
        startRtp(reason);
    }

    private void startMining(int count) {
        rtpTries = 0;
        errors = 0;

        if (baritoneMineAgain.get()) {
            Block[] blocks = targetBlocks.get().toArray(new Block[0]);
            if (blocks.length == 0) {
                resumeOthers();
                error("block-can-dao dang trong, Baritone khong biet dao gi.");
                toggle();
                return;
            }
            PathManagers.get().mine(blocks);
        }
        resumeOthers();
        info("Thay %d block cat dao duoc. Baritone dao tiep.", count);

        state = State.MINING;
        stateTicks = 0;
        idleTicks = 0;
        emptyChecks = 0;
        busyGrace = 0;
        warnedNoShovel = false;
        resetStuck();
        mineStartY = mc.player.getBlockY();
    }

    private void tickMining() {
        stateTicks++;
        if (stateTicks < 60) { // cho Baritone tinh duong
            resetStuck();
            return;
        }

        // Module khac (Sand Helper) dang ban/mua/rtp: no tam dung Baritone, khong phai het cat / ket.
        if (otherBusy()) {
            idleTicks = 0;
            emptyChecks = 0;
            busyGrace = 100; // sau khi no xong, cho Baritone chay lai 5 giay roi moi theo doi tiep
            resetStuck();
            return;
        }
        if (busyGrace > 0) {
            busyGrace--;
            idleTicks = 0;
            resetStuck();
            return;
        }

        // Mau thap thi /rtp de thoat (cooldown 30 giay de khong lap RTP lien tuc khi dang yeu).
        if (rtpLowHealth.get()) {
            if (healthCooldown > 0) {
                healthCooldown--;
            } else if (mc.currentScreen == null) {
                float pct = mc.player.getHealth() / mc.player.getMaxHealth() * 100f;
                if (pct < lowHealthPercent.get()) {
                    info("Mau con %d%% (duoi %d%%), /rtp.", Math.round(pct), lowHealthPercent.get());
                    healthCooldown = 600;
                    startRtp("mau thap");
                    return;
                }
            }
        }

        // Tay khong cam xeng thi cam lai.
        if (autoShovel.get() && stateTicks % 10 == 0) ensureShovel();

        // Dung yen qua lau (Baritone ket, khong dat/dao duoc block, block ma...) thi /rtp.
        if (rtpWhenStuck.get()) {
            double dx = mc.player.getX() - stuckX;
            double dy = mc.player.getY() - stuckY;
            double dz = mc.player.getZ() - stuckZ;
            double lim = stuckDistance.get();
            if (dx * dx + dy * dy + dz * dz > lim * lim) {
                resetStuck();
            } else if (++stuckTicks >= stuckSeconds.get() * 20) {
                info("Dung yen qua %d giay (co the bi ket), /rtp.", stuckSeconds.get());
                startRtp("dung yen qua lau");
                return;
            }
        }

        if (!baritoneMineAgain.get()) return;

        // Chong Baritone dao xuong long dat khi het cat.
        if (maxDrop.get() > 0 && stateTicks % 10 == 0 && mineStartY - mc.player.getBlockY() > maxDrop.get()) {
            info("Baritone dao xuong sau hon %d block, dung va /rtp.", maxDrop.get());
            startRtp("dao xuong sau");
            return;
        }

        // Het cat quanh day (trong ban kinh chunk) thi /rtp. Con cat o dau do Baritone van co the toi thi khong RTP.
        if (checkEmptyWhileMining.get() && stateTicks % 40 == 0) {
            int r = emptyRadius.get();
            ScanResult res = scanChunks((mc.player.getBlockX() >> 4) - r, (mc.player.getBlockZ() >> 4) - r,
                2 * r + 1, emptyBelow.get());
            if (res.sand() < emptyBelow.get()) {
                if (++emptyChecks >= 2) {
                    info("Het cat trong %d chunk quanh day (con %d). Dung Baritone va /rtp.", r, res.sand());
                    startRtp("het cat quanh day");
                    return;
                }
            } else {
                emptyChecks = 0;
            }
        }

        if (PathManagers.get().isPathing()) {
            idleTicks = 0;
            return;
        }
        // Baritone dung han thi /rtp.
        if (++idleTicks >= baritoneIdleTicks.get()) {
            info("Baritone da dung dao, /rtp.");
            startRtp("Baritone dung");
        }
    }

    private void ensureShovel() {
        if (mc.currentScreen != null) return;
        if (mc.player.getMainHandStack().isIn(ItemTags.SHOVELS)) return;

        BlockState sand = Blocks.SAND.getDefaultState();
        int best = -1;
        float bestSpeed = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (st.isEmpty() || !st.isIn(ItemTags.SHOVELS)) continue;
            float sp = st.getMiningSpeedMultiplier(sand);
            if (best < 0 || sp > bestSpeed) {
                best = i;
                bestSpeed = sp;
            }
        }

        if (best >= 0) {
            InvUtils.swap(best, false);
            dbg("Cam lai xeng o slot hotbar " + best);
        } else if (mc.player.getOffHandStack().isIn(ItemTags.SHOVELS)) {
            // Xeng ket o tay trai (Sand Helper dua sang tay trai de sua Mending): doi tay de lay ra.
            swapOffhand();
            dbg("Xeng dang o tay trai, doi tay de cam lai.");
        } else if (!warnedNoShovel) {
            warnedNoShovel = true;
            warning("Khong thay xeng trong hotbar, dang dao bang tay.");
        }
    }

    private void swapOffhand() {
        if (mc.getNetworkHandler() == null) return;
        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
            PlayerActionC2SPacket.Action.SWAP_ITEMS_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
    }

    private void resetStuck() {
        stuckTicks = 0;
        if (mc.player != null) {
            stuckX = mc.player.getX();
            stuckY = mc.player.getY();
            stuckZ = mc.player.getZ();
        }
    }

    /** Module khac (theo ten) dang o trang thai ban/mua/rtp? Doc qua getInfoString (Sand Helper tra ve ten state). */
    private boolean otherBusy() {
        // Dang an / dung item (Auto Eat cua Meteor cung pause Baritone khi an): khong phai het cat.
        if (mc.player != null && mc.player.isUsingItem()) return true;
        if (autoEatEating()) return true;

        for (String name : yieldModules.get()) {
            if (name == null || name.isBlank()) continue;
            Module m = Modules.get().get(name.trim());
            if (m == null || m == this || !m.isActive()) continue;
            String info = m.getInfoString();
            if (info == null) continue;
            info = info.trim();
            if (info.isEmpty() || info.equalsIgnoreCase("IDLE") || info.equalsIgnoreCase("COOLDOWN")) continue;
            return true;
        }
        return false;
    }

    private Field eatingField;
    private boolean eatingLookedUp;

    /** Doc co "eating" cua Auto Eat (Meteor) bang reflection de khong phu thuoc ten ham/truong luc bien dich. */
    private boolean autoEatEating() {
        Module m = Modules.get().get("auto-eat");
        if (m == null || !m.isActive()) return false;
        try {
            if (!eatingLookedUp) {
                eatingLookedUp = true;
                try { eatingField = m.getClass().getField("eating"); } catch (Throwable ignored) { eatingField = null; }
            }
            return eatingField != null && eatingField.getBoolean(m);
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean isOcean() {
        BlockPos p = mc.player.getBlockPos();
        return mc.world.getBiome(p).isIn(BiomeTags.IS_OCEAN);
    }

    /** Quet vung N x N chunk quanh ban, chi dem block dao duoc. */
    private ScanResult scan() {
        int px = mc.player.getBlockX();
        int pz = mc.player.getBlockZ();
        int pcx = px >> 4;
        int pcz = pz >> 4;
        int n = areaSize.get();

        int sx;
        int sz;
        if (n == 1) {
            sx = pcx;
            sz = pcz;
        } else if (n == 2) {
            // 4 chunk sat ban nhat: lay chunk dang dung + chunk ben canh o phia ban dang dung gan
            sx = pcx + ((px & 15) < 8 ? -1 : 0);
            sz = pcz + ((pz & 15) < 8 ? -1 : 0);
        } else {
            sx = pcx - 1;
            sz = pcz - 1;
        }
        return scanChunks(sx, sz, n, 0);
    }

    /** Quet n x n chunk bat dau tai (sx, sz). limit > 0: dung som khi dem du limit block. */
    private ScanResult scanChunks(int sx, int sz, int n, int limit) {
        Set<Block> targets = new HashSet<>(targetBlocks.get());
        Predicate<BlockState> pred = s -> targets.contains(s.getBlock());

        int py = mc.player.getBlockY();
        int dyMax = maxDy.get();
        int bottom = mc.world.getBottomSectionCoord();
        BlockPos.Mutable above = new BlockPos.Mutable();

        int count = 0;
        int hidden = 0;
        boolean allLoaded = true;

        outer:
        for (int cx = sx; cx < sx + n; cx++) {
            for (int cz = sz; cz < sz + n; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) {
                    allLoaded = false;
                    continue;
                }

                ChunkSection[] sections = chunk.getSectionArray();
                for (int i = 0; i < sections.length; i++) {
                    ChunkSection sec = sections[i];
                    if (sec == null || sec.isEmpty()) continue;
                    if (!sec.getBlockStateContainer().hasAny(pred)) continue;

                    int baseY = (bottom + i) << 4;
                    if (Math.abs(baseY + 8 - py) > dyMax + 16) continue;

                    for (int x = 0; x < 16; x++) {
                        for (int y = 0; y < 16; y++) {
                            int wy = baseY + y;
                            if (Math.abs(wy - py) > dyMax) continue;
                            for (int z = 0; z < 16; z++) {
                                if (!pred.test(sec.getBlockState(x, y, z))) continue;

                                if (skipUnderwater.get()) {
                                    above.set((cx << 4) + x, wy + 1, (cz << 4) + z);
                                    if (!mc.world.getFluidState(above).isEmpty()) {
                                        hidden++;
                                        continue;
                                    }
                                }
                                count++;
                                if (limit > 0 && count >= limit) break outer;
                            }
                        }
                    }
                }
            }
        }

        return new ScanResult(count, hidden, allLoaded, n * n);
    }

    // ---------------------------------------------------------------- tam dung / khoi phuc

    private void pauseOthers() {
        // Giong Sand Helper: PAUSE Baritone (khong stop/cancel), xong thi resume.
        if (stopBaritone.get() && !baritonePaused) {
            try {
                if (PathManagers.get().isPathing()) {
                    PathManagers.get().pause();
                    baritonePaused = true;
                }
            } catch (Throwable ignored) { }
        }
        for (Module m : pauseModules.get()) {
            if (m != null && m != this && m.isActive() && !pausedModules.contains(m)) {
                m.toggle();
                pausedModules.add(m);
            }
        }
    }

    private void resumeOthers() {
        if (baritonePaused) {
            try { PathManagers.get().resume(); } catch (Throwable ignored) { }
            baritonePaused = false;
        }
        for (Module m : pausedModules) {
            if (!m.isActive()) m.toggle();
        }
        pausedModules.clear();
    }

    // ---------------------------------------------------------------- loi

    private void fail(String msg) {
        errors++;
        closeScreen();
        if (errors >= maxErrors.get()) {
            error("Loi %d lan lien tiep, tat rtp-helper. %s", errors, msg);
            info("Nuker/Baritone da duoc dung lai. Sua loi roi bat lai bang tay.");
            resumeOthers();
            try { PathManagers.get().stop(); } catch (Throwable ignored) { }
            toggle();
            return;
        }
        info("RTP that bai: %s Thu lai sau %d tick.", msg, retryWait.get());
        state = State.RTP_COOLDOWN;
        wait = retryWait.get();
    }

    private void dbg(String s) {
        if (debug.get()) info("[debug] %s", s);
    }

    // ---------------------------------------------------------------- tien ich

    private int nextDelay() {
        int extra = randomDelay.get();
        return stepDelay.get() + (extra > 0 ? ThreadLocalRandom.current().nextInt(extra + 1) : 0);
    }

    private static String norm(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.replace('\u0111', 'd').replace('\u0110', 'D').toLowerCase();
    }

    private int parseCooldownTicks(String msg) {
        Matcher m = Pattern.compile("(\\d+)").matcher(msg);
        if (!m.find()) return retryWait.get();
        int v = Integer.parseInt(m.group(1));
        if (msg.contains("phut") || msg.contains("minute")) v *= 60;
        return Math.max(20, v * 20 + 20);
    }

    private List<Step> parseScript(List<String> lines) {
        List<Step> out = new ArrayList<>();
        for (String raw : lines) {
            String line = raw == null ? "" : raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;

            Step s = new Step();
            s.raw = line;
            if (line.startsWith("?")) {
                s.optional = true;
                line = line.substring(1).trim();
            }
            int amp = line.indexOf('&'); // "& any" = bat ky item nao cung duoc
            if (amp >= 0) line = line.substring(0, amp).trim();

            String[] p = line.split("\\s+", 2);
            String cmd = p[0].toLowerCase();
            String arg = p.length > 1 ? p[1].trim() : "";

            try {
                switch (cmd) {
                    case "wait" -> {
                        s.kind = Kind.WAIT;
                        s.num = Integer.parseInt(arg);
                    }
                    case "cmd" -> {
                        s.kind = Kind.CMD;
                        s.arg = arg;
                    }
                    case "waitgui" -> s.kind = Kind.WAITGUI;
                    case "close" -> s.kind = Kind.CLOSE;
                    case "click" -> {
                        s.kind = Kind.CLICK;
                        if (arg.startsWith("slot:")) {
                            s.bySlot = true;
                            s.slot = Integer.parseInt(arg.substring(5).trim());
                        } else if (arg.startsWith("id:")) {
                            s.id = arg.substring(3).trim().toLowerCase();
                        } else {
                            throw new IllegalArgumentException("click can slot:N hoac id:xxx");
                        }
                    }
                    default -> throw new IllegalArgumentException("lenh la: " + cmd);
                }
                out.add(s);
            } catch (Exception e) {
                warning("Bo qua dong script khong hop le '%s' (%s)", s.raw, e.getMessage());
            }
        }
        return out;
    }
}
