package com.rtphelper;

import com.mojang.logging.LogUtils;
import com.rtphelper.commands.RtpHelperCommand;
import com.rtphelper.modules.RtpHelper;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.commands.Commands;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.item.Items;
import org.slf4j.Logger;

public class RtpHelperAddon extends MeteorAddon {
    public static final Logger LOG = LogUtils.getLogger();
    public static final Category CATEGORY = new Category("RTP Helper", Items.ENDER_PEARL.getDefaultStack());

    @Override
    public void onInitialize() {
        LOG.info("Initializing RTP Helper");
        Modules.get().add(new RtpHelper());
        Commands.add(new RtpHelperCommand());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.rtphelper";
    }
}
