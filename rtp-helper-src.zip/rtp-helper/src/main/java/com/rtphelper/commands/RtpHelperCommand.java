package com.rtphelper.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.rtphelper.modules.RtpHelper;
import meteordevelopment.meteorclient.commands.Command;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.command.CommandSource;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;
import static com.mojang.brigadier.builder.LiteralArgumentBuilder.literal;

public class RtpHelperCommand extends Command {
    public RtpHelperCommand() {
        super("rtphelper", "Dieu khien RTP Helper: rtp | stop | status | scan", "rh");
    }

    private RtpHelper mod() {
        return Modules.get().get(RtpHelper.class);
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("rtp").executes(ctx -> {
            if (!mod().isActive()) {
                error("Bat module rtp-helper truoc (Meteor GUI > RTP Helper).");
                return SINGLE_SUCCESS;
            }
            info("Se /rtp ngay (lap lai toi khi co cat).");
            mod().requestRtp();
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("stop").executes(ctx -> {
            mod().stopAll();
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("status").executes(ctx -> {
            mod().printStatus();
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("scan").executes(ctx -> {
            mod().printScan();
            return SINGLE_SUCCESS;
        }));

        builder.executes(ctx -> {
            info("Dung: .rtphelper rtp | stop | status | scan");
            return SINGLE_SUCCESS;
        });
    }
}
